// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {LuckyDraw} from "../LuckyDraw.sol";

/// @dev Simple 6-decimal ERC20 with a per-recipient blocklist applied to `transfer`.
contract MockUSDC {
    string public name = "Mock USDC";
    string public symbol = "mUSDC";
    uint8 public decimals = 6;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => bool) public blocked;
    bool public returnFalseWhenBlocked;

    function mint(address to, uint256 amt) external {
        balanceOf[to] += amt;
        totalSupply += amt;
    }

    function setBlocked(address who, bool b) external {
        blocked[who] = b;
    }

    function setReturnFalse(bool b) external {
        returnFalseWhenBlocked = b;
    }

    function approve(address s, uint256 amt) external returns (bool) {
        allowance[msg.sender][s] = amt;
        return true;
    }

    function transfer(address to, uint256 amt) external returns (bool) {
        if (blocked[to]) {
            if (returnFalseWhenBlocked) return false;
            revert("blocked");
        }
        return _move(msg.sender, to, amt);
    }

    function transferFrom(address from, address to, uint256 amt) external returns (bool) {
        uint256 a = allowance[from][msg.sender];
        require(a >= amt, "allowance");
        if (a != type(uint256).max) allowance[from][msg.sender] = a - amt;
        return _move(from, to, amt);
    }

    function _move(address from, address to, uint256 amt) internal returns (bool) {
        require(balanceOf[from] >= amt, "balance");
        balanceOf[from] -= amt;
        balanceOf[to] += amt;
        return true;
    }
}

abstract contract LuckyDrawBase is Test {
    LuckyDraw internal raffle;
    MockUSDC internal usdc;

    address internal owner = makeAddr("owner");
    address internal treasury = makeAddr("treasury");
    address internal alice = makeAddr("alice");
    address internal bob = makeAddr("bob");
    address internal carol = makeAddr("carol");

    uint16 internal constant FEE = 300;
    uint256 internal constant PRICE = 1e6;
    uint32 internal constant MAXT = 10;
    uint64 internal constant DUR = 1 days;

    function setUp() public virtual {
        vm.warp(1_000_000);
        vm.roll(100);
        usdc = new MockUSDC();
        raffle = new LuckyDraw(address(usdc), treasury, FEE, owner);
        address[3] memory users = [alice, bob, carol];
        for (uint256 i; i < users.length; ++i) {
            usdc.mint(users[i], 1e15);
            vm.prank(users[i]);
            usdc.approve(address(raffle), type(uint256).max);
        }
    }

    function _create(uint256 price, uint32 max, uint64 dur) internal returns (uint256) {
        vm.prank(alice);
        return raffle.createRaffle(price, max, dur);
    }

    function _createDefault() internal returns (uint256) {
        return _create(PRICE, MAXT, DUR);
    }

    function _buy(address who, uint256 id, uint32 q) internal {
        vm.prank(who);
        raffle.buyTickets(id, q);
    }

    /// alice 6 + bob 4 -> sold out on a 10-ticket raffle
    function _fill(uint256 id) internal {
        _buy(alice, id, 6);
        _buy(bob, id, 4);
    }

    function _nextBlock() internal {
        vm.roll(block.number + 1);
    }

    function _draw(uint256 id) internal {
        _nextBlock();
        raffle.drawRaffle(id);
    }

    function _predict(uint256 id) internal view returns (address w, uint32 t) {
        LuckyDraw.Raffle memory r = raffle.getRaffle(id);
        uint256 seed = uint256(keccak256(abi.encodePacked(blockhash(block.number - 1), id, r.ticketsSold, address(raffle))));
        t = uint32(seed % r.ticketsSold);
        w = raffle.getTicketOwner(id, t);
    }
}

contract LuckyDrawTest is LuckyDrawBase {
    // ---------------------------------------------------------------- constructor
    function test_Constructor_SetsState() public view {
        assertEq(address(raffle.usdc()), address(usdc));
        assertEq(raffle.treasury(), treasury);
        assertEq(raffle.feeBps(), FEE);
        assertEq(raffle.owner(), owner);
        assertEq(raffle.nextRaffleId(), 1);
        assertEq(raffle.raffleCount(), 0);
        assertEq(raffle.accruedFees(), 0);
    }

    function test_Constructor_FeeBoundariesAccepted() public {
        assertEq(new LuckyDraw(address(usdc), treasury, 200, owner).feeBps(), 200);
        assertEq(new LuckyDraw(address(usdc), treasury, 500, owner).feeBps(), 500);
    }

    function test_Constructor_RevertsFeeTooHigh() public {
        vm.expectRevert(LuckyDraw.FeeTooHigh.selector);
        new LuckyDraw(address(usdc), treasury, 501, owner);
    }

    function test_Constructor_RevertsFeeTooLow() public {
        vm.expectRevert(LuckyDraw.FeeTooLow.selector);
        new LuckyDraw(address(usdc), treasury, 199, owner);
        vm.expectRevert(LuckyDraw.FeeTooLow.selector);
        new LuckyDraw(address(usdc), treasury, 0, owner);
    }

    function test_Constructor_RevertsZeroUsdcOrTreasury() public {
        vm.expectRevert(LuckyDraw.ZeroAddress.selector);
        new LuckyDraw(address(0), treasury, FEE, owner);
        vm.expectRevert(LuckyDraw.ZeroAddress.selector);
        new LuckyDraw(address(usdc), address(0), FEE, owner);
    }

    /// Ownable's constructor runs first, so a zero owner surfaces as OwnableInvalidOwner.
    function test_Constructor_RevertsZeroOwner() public {
        vm.expectRevert(abi.encodeWithSelector(Ownable.OwnableInvalidOwner.selector, address(0)));
        new LuckyDraw(address(usdc), treasury, FEE, address(0));
    }

    // ---------------------------------------------------------------- createRaffle
    function test_Create_StoresRaffleAndEmits() public {
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.RaffleCreated(1, alice, PRICE, MAXT, uint64(block.timestamp + DUR), FEE);
        uint256 id = _createDefault();
        assertEq(id, 1);
        assertEq(raffle.raffleCount(), 1);
        LuckyDraw.Raffle memory r = raffle.getRaffle(1);
        assertEq(r.creator, alice);
        assertEq(r.ticketPrice, PRICE);
        assertEq(r.maxTickets, MAXT);
        assertEq(r.ticketsSold, 0);
        assertEq(r.createdAt, block.timestamp);
        assertEq(r.endTime, block.timestamp + DUR);
        assertEq(r.feeBps, FEE);
        assertEq(uint8(r.status), uint8(LuckyDraw.Status.Active));
        assertEq(r.winner, address(0));
    }

    function test_Create_IdsIncrement() public {
        assertEq(_createDefault(), 1);
        assertEq(_createDefault(), 2);
        assertEq(raffle.raffleCount(), 2);
    }

    function test_Create_BoundariesAccepted() public {
        _create(raffle.MIN_TICKET_PRICE(), 2, 60);
        _create(1e18, 1000, 30 days);
        assertEq(raffle.raffleCount(), 2);
    }

    function test_Create_RevertsBadPrice() public {
        vm.expectRevert(LuckyDraw.InvalidTicketPrice.selector);
        _create(9_999, 10, DUR);
    }

    function test_Create_RevertsBadMaxTickets() public {
        vm.expectRevert(LuckyDraw.InvalidMaxTickets.selector);
        _create(PRICE, 1, DUR);
        vm.expectRevert(LuckyDraw.InvalidMaxTickets.selector);
        _create(PRICE, 1001, DUR);
    }

    function test_Create_RevertsBadDuration() public {
        vm.expectRevert(LuckyDraw.InvalidDuration.selector);
        _create(PRICE, 10, 59);
        vm.expectRevert(LuckyDraw.InvalidDuration.selector);
        _create(PRICE, 10, 30 days + 1);
    }

    function test_Create_RevertsTimestampOverflow() public {
        vm.warp(uint256(type(uint64).max) - 10);
        vm.expectRevert(LuckyDraw.TimestampOverflow.selector);
        _create(PRICE, 10, 60);
    }

    function test_Create_SnapshotsFeeAtCreation() public {
        uint256 id = _createDefault();
        vm.prank(owner);
        raffle.setFeeBps(500);
        uint256 id2 = _createDefault();
        assertEq(raffle.getRaffle(id).feeBps, 300);
        assertEq(raffle.getRaffle(id2).feeBps, 500);
    }

    // ---------------------------------------------------------------- buyTickets
    function test_Buy_RecordsTicketsAndEmits() public {
        uint256 id = _createDefault();
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.TicketsPurchased(id, alice, 3, 0, 3 * PRICE, 3);
        _buy(alice, id, 3);
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.TicketsPurchased(id, bob, 2, 3, 2 * PRICE, 5);
        _buy(bob, id, 2);

        assertEq(raffle.getRaffle(id).ticketsSold, 5);
        assertEq(raffle.ticketsOf(id, alice), 3);
        assertEq(raffle.ticketsOf(id, bob), 2);
        assertEq(usdc.balanceOf(address(raffle)), 5 * PRICE);
        assertEq(usdc.balanceOf(alice), 1e15 - 3 * PRICE);
    }

    function test_Buy_RepeatBuyerNotDuplicatedAsParticipant() public {
        uint256 id = _createDefault();
        _buy(alice, id, 1);
        _buy(alice, id, 2);
        assertEq(raffle.participantCount(id), 1);
        assertEq(raffle.ticketsOf(id, alice), 3);
        for (uint256 i; i < 3; ++i) assertEq(raffle.getTicketOwner(id, i), alice);
    }

    function test_Buy_RevertsUnknownRaffle() public {
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 0));
        _buy(alice, 0, 1);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 1));
        _buy(alice, 1, 1);
    }

    function test_Buy_RevertsZeroQuantity() public {
        uint256 id = _createDefault();
        vm.expectRevert(LuckyDraw.InvalidQuantity.selector);
        _buy(alice, id, 0);
    }

    function test_Buy_RevertsOverCapacity() public {
        uint256 id = _createDefault();
        vm.expectRevert(LuckyDraw.NotEnoughTickets.selector);
        _buy(alice, id, 11);
        _buy(alice, id, 6);
        vm.expectRevert(LuckyDraw.NotEnoughTickets.selector);
        _buy(bob, id, 5);
        _buy(bob, id, 4); // exactly fills
    }

    function test_Buy_RevertsAtAndAfterEndTime() public {
        uint256 id = _createDefault();
        uint64 end = raffle.getRaffle(id).endTime;
        vm.warp(end - 1);
        _buy(alice, id, 1); // last second still allowed
        vm.warp(end);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.SalesEnded.selector, id));
        _buy(alice, id, 1);
        vm.warp(end + 1 days);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.SalesEnded.selector, id));
        _buy(alice, id, 1);
    }

    function test_Buy_RevertsWhenNotActive() public {
        uint256 id = _createDefault();
        _fill(id);
        _draw(id);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotActive.selector, id));
        _buy(alice, id, 1);
    }

    function test_Buy_RevertsWithoutAllowanceAndLeavesNoState() public {
        uint256 id = _createDefault();
        address dave = makeAddr("dave");
        usdc.mint(dave, 1e9);
        vm.expectRevert();
        _buy(dave, id, 1);
        assertEq(raffle.getRaffle(id).ticketsSold, 0);
        assertEq(raffle.participantCount(id), 0);
    }

    // ---------------------------------------------------------------- drawRaffle
    function test_Draw_SoldOutPaysPotMinusFee() public {
        uint256 id = _createDefault();
        _fill(id);
        _nextBlock();
        (address w, uint32 t) = _predict(id);
        uint256 balBefore = usdc.balanceOf(w);

        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.FeeSent(id, treasury, 300_000);
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.PayoutSent(id, w, 9_700_000);
        vm.expectEmit(true, true, true, true, address(raffle));
        emit LuckyDraw.RaffleDrawn(id, w, t, 10e6, 300_000, 9_700_000, block.number, carol);
        vm.prank(carol);
        raffle.drawRaffle(id);

        LuckyDraw.Raffle memory r = raffle.getRaffle(id);
        assertEq(uint8(r.status), uint8(LuckyDraw.Status.Drawn));
        assertEq(r.winner, w);
        assertEq(r.winningTicket, t);
        assertEq(r.pot, 10e6);
        assertEq(r.fee, 300_000);
        assertEq(r.payout, 9_700_000);
        assertEq(r.drawBlock, block.number);
        assertEq(r.drawnAt, block.timestamp);
        assertEq(usdc.balanceOf(w), balBefore + 9_700_000);
        assertEq(usdc.balanceOf(address(raffle)), 0);
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(raffle.accruedFees(), 0);
        assertEq(raffle.claimable(w), 0);
    }

    function test_Draw_AfterEndTimePartialSale() public {
        uint256 id = _createDefault();
        _buy(alice, id, 2);
        _buy(bob, id, 1);
        vm.warp(raffle.getRaffle(id).endTime);
        _draw(id);
        LuckyDraw.Raffle memory r = raffle.getRaffle(id);
        assertEq(uint8(r.status), uint8(LuckyDraw.Status.Drawn));
        assertEq(r.pot, 3e6);
        assertEq(r.fee, 90_000);
        assertEq(r.payout, 2_910_000);
        assertTrue(r.winner == alice || r.winner == bob);
    }

    function test_Draw_SingleTicketRaffleAfterExpiry() public {
        uint256 id = _createDefault();
        _buy(alice, id, 1);
        vm.warp(raffle.getRaffle(id).endTime);
        _draw(id);
        assertEq(raffle.getRaffle(id).winner, alice);
        assertEq(raffle.getRaffle(id).winningTicket, 0);
    }

    function test_Draw_FeeUsesSnapshotNotCurrentFee() public {
        uint256 id = _createDefault();
        _fill(id);
        vm.prank(owner);
        raffle.setFeeBps(500);
        _draw(id);
        assertEq(raffle.getRaffle(id).fee, 300_000);
    }

    function test_Draw_RevertsTooEarly() public {
        uint256 id = _createDefault();
        _buy(alice, id, 3);
        _nextBlock();
        vm.expectRevert(LuckyDraw.NotReadyToDraw.selector);
        raffle.drawRaffle(id);
        vm.warp(raffle.getRaffle(id).endTime - 1);
        vm.expectRevert(LuckyDraw.NotReadyToDraw.selector);
        raffle.drawRaffle(id);
    }

    function test_Draw_RevertsSameBlockAsLastPurchase_SoldOut() public {
        uint256 id = _createDefault();
        _fill(id);
        vm.expectRevert(LuckyDraw.SameBlockAsLastPurchase.selector);
        raffle.drawRaffle(id);
        _nextBlock();
        raffle.drawRaffle(id);
    }

    function test_Draw_RevertsSameBlockAsLastPurchase_Expired() public {
        uint256 id = _createDefault();
        _buy(alice, id, 2);
        vm.warp(raffle.getRaffle(id).endTime);
        vm.expectRevert(LuckyDraw.SameBlockAsLastPurchase.selector);
        raffle.drawRaffle(id);
    }

    function test_Draw_RevertsUnknownAndAlreadyDrawn() public {
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 5));
        raffle.drawRaffle(5);
        uint256 id = _createDefault();
        _fill(id);
        _draw(id);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotActive.selector, id));
        raffle.drawRaffle(id);
    }

    function test_Draw_ZeroTicketsCancels() public {
        uint256 id = _createDefault();
        vm.warp(raffle.getRaffle(id).endTime);
        vm.expectEmit(true, false, false, false, address(raffle));
        emit LuckyDraw.RaffleCancelled(id);
        raffle.drawRaffle(id); // same block as nothing: allowed
        assertEq(uint8(raffle.getRaffle(id).status), uint8(LuckyDraw.Status.Cancelled));
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotActive.selector, id));
        raffle.drawRaffle(id);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotActive.selector, id));
        _buy(alice, id, 1);
    }

    function test_Draw_ZeroTicketsBeforeEndReverts() public {
        uint256 id = _createDefault();
        vm.expectRevert(LuckyDraw.NotReadyToDraw.selector);
        raffle.drawRaffle(id);
    }
}
