// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {LuckyDraw} from "../LuckyDraw.sol";
import {LuckyDrawBase} from "./LuckyDraw.t.sol";

contract LuckyDrawViewsTest is LuckyDrawBase {
    function _phase(uint256 id) internal view returns (LuckyDraw.Phase) {
        return raffle.getStatus(id);
    }

    // ---------------------------------------------------------------- getRaffle / getRaffles
    function test_GetRaffle_RevertsUnknown() public {
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 0));
        raffle.getRaffle(0);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 1));
        raffle.getRaffle(1);
    }

    function test_GetRaffles_ReturnsAscendingRange() public {
        for (uint256 i; i < 5; ++i) _createDefault();
        LuckyDraw.Raffle[] memory rs = raffle.getRaffles(2, 3);
        assertEq(rs.length, 3);
        for (uint256 i; i < 3; ++i) assertEq(rs[i].endTime, raffle.getRaffle(2 + i).endTime);
        // distinguish by price to prove ordering
        _create(2e6, 5, DUR); // id 6
        rs = raffle.getRaffles(6, 1);
        assertEq(rs[0].ticketPrice, 2e6);
    }

    function test_GetRaffles_ClampsToEnd() public {
        for (uint256 i; i < 5; ++i) _createDefault();
        assertEq(raffle.getRaffles(4, 100).length, 2);
        assertEq(raffle.getRaffles(5, 1).length, 1);
        assertEq(raffle.getRaffles(1, type(uint256).max).length, 5);
    }

    function test_GetRaffles_EmptyCases() public {
        assertEq(raffle.getRaffles(1, 10).length, 0); // none created
        for (uint256 i; i < 3; ++i) _createDefault();
        assertEq(raffle.getRaffles(0, 10).length, 0); // fromId zero
        assertEq(raffle.getRaffles(4, 10).length, 0); // beyond last
        assertEq(raffle.getRaffles(type(uint256).max, 10).length, 0);
        assertEq(raffle.getRaffles(1, 0).length, 0); // count zero
    }

    // ---------------------------------------------------------------- participants / owners
    function test_GetParticipants_FirstPurchaseOrderNoDuplicates() public {
        uint256 id = _createDefault();
        _buy(bob, id, 1);
        _buy(alice, id, 1);
        _buy(bob, id, 1);
        _buy(carol, id, 1);
        address[] memory ps = raffle.getParticipants(id);
        assertEq(ps.length, 3);
        assertEq(ps[0], bob);
        assertEq(ps[1], alice);
        assertEq(ps[2], carol);
        assertEq(raffle.participantCount(id), 3);
    }

    function test_GetParticipants_RevertsUnknown() public {
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 9));
        raffle.getParticipants(9);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 9));
        raffle.participantCount(9);
    }

    function test_GetTicketOwner_InterleavedPurchases() public {
        uint256 id = _createDefault();
        _buy(alice, id, 2); // 0,1
        _buy(bob, id, 3); // 2,3,4
        _buy(alice, id, 1); // 5
        _buy(carol, id, 2); // 6,7
        address[8] memory expected = [alice, alice, bob, bob, bob, alice, carol, carol];
        for (uint256 i; i < 8; ++i) {
            assertEq(raffle.getTicketOwner(id, i), expected[i]);
        }
    }

    function test_GetTicketOwner_RevertsOutOfRangeAndUnknown() public {
        uint256 id = _createDefault();
        vm.expectRevert(LuckyDraw.InvalidTicketIndex.selector);
        raffle.getTicketOwner(id, 0); // none sold
        _buy(alice, id, 2);
        vm.expectRevert(LuckyDraw.InvalidTicketIndex.selector);
        raffle.getTicketOwner(id, 2);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 7));
        raffle.getTicketOwner(7, 0);
    }

    function test_GetUserRaffles_CreatedAndJoined() public {
        uint256 a = _createDefault(); // by alice
        vm.prank(bob);
        uint256 b = raffle.createRaffle(PRICE, 5, DUR);
        _buy(alice, b, 1);
        _buy(alice, b, 1); // no duplicate join
        _buy(alice, a, 1);
        _buy(carol, a, 1);

        (uint256[] memory created, uint256[] memory joined) = raffle.getUserRaffles(alice);
        assertEq(created.length, 1);
        assertEq(created[0], a);
        assertEq(joined.length, 2);
        assertEq(joined[0], b);
        assertEq(joined[1], a);

        (created, joined) = raffle.getUserRaffles(bob);
        assertEq(created.length, 1);
        assertEq(created[0], b);
        assertEq(joined.length, 0);

        (created, joined) = raffle.getUserRaffles(carol);
        assertEq(created.length, 0);
        assertEq(joined.length, 1);
        assertEq(joined[0], a);
    }

    // ---------------------------------------------------------------- getStatus / timeRemaining
    function test_GetStatus_ActiveThenReadyOnSellout() public {
        uint256 id = _createDefault();
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.Active));
        _buy(alice, id, 3);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.Active));
        _buy(bob, id, 7);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.ReadyToDraw));
    }

    function test_GetStatus_ReadyToDrawAfterExpiryWithTickets() public {
        uint256 id = _createDefault();
        _buy(alice, id, 1);
        vm.warp(raffle.getRaffle(id).endTime - 1);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.Active));
        vm.warp(raffle.getRaffle(id).endTime);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.ReadyToDraw));
    }

    function test_GetStatus_ExpiredEmptyThenCancelled() public {
        uint256 id = _createDefault();
        vm.warp(raffle.getRaffle(id).endTime);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.ExpiredEmpty));
        raffle.drawRaffle(id);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.Cancelled));
    }

    function test_GetStatus_Drawn() public {
        uint256 id = _createDefault();
        _fill(id);
        _draw(id);
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.Drawn));
    }

    function test_GetStatus_IndependentOfPause() public {
        uint256 id = _createDefault();
        vm.prank(owner);
        raffle.pause();
        assertEq(uint8(_phase(id)), uint8(LuckyDraw.Phase.Active));
    }

    function test_GetStatus_RevertsUnknown() public {
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 3));
        raffle.getStatus(3);
        vm.expectRevert(abi.encodeWithSelector(LuckyDraw.RaffleNotFound.selector, 3));
        raffle.timeRemaining(3);
    }

    function test_TimeRemaining_CountsDownToZero() public {
        uint256 id = _createDefault();
        assertEq(raffle.timeRemaining(id), DUR);
        skip(100);
        assertEq(raffle.timeRemaining(id), DUR - 100);
        vm.warp(raffle.getRaffle(id).endTime);
        assertEq(raffle.timeRemaining(id), 0);
        skip(5 days);
        assertEq(raffle.timeRemaining(id), 0);
    }
}
