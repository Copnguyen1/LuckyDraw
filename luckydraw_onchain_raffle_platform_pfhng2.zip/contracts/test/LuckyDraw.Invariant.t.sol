// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {LuckyDraw} from "../LuckyDraw.sol";
import {MockUSDC} from "./LuckyDraw.t.sol";

contract LuckyDrawHandler is Test {
    LuckyDraw public raffle;
    MockUSDC public usdc;
    address[] public actors;
    uint256 public maxId;

    constructor(LuckyDraw r, MockUSDC u) {
        raffle = r;
        usdc = u;
        for (uint256 i; i < 3; ++i) {
            address a = makeAddr(string(abi.encodePacked("actor", vm.toString(i))));
            actors.push(a);
            u.mint(a, 1e15);
            vm.prank(a);
            u.approve(address(r), type(uint256).max);
        }
    }

    function actorCount() external view returns (uint256) {
        return actors.length;
    }

    function create(uint256 actorSeed, uint256 price, uint32 maxT, uint64 dur) external {
        price = bound(price, 10_000, 1e9);
        maxT = uint32(bound(maxT, 2, 50));
        dur = uint64(bound(dur, 60, 3 days));
        vm.prank(actors[actorSeed % 3]);
        raffle.createRaffle(price, maxT, dur);
        maxId = raffle.raffleCount();
    }

    function buy(uint256 actorSeed, uint256 idSeed, uint32 qty) external {
        if (maxId == 0) return;
        uint256 id = bound(idSeed, 1, maxId);
        LuckyDraw.Raffle memory r = raffle.getRaffle(id);
        if (r.status != LuckyDraw.Status.Active || block.timestamp >= r.endTime) return;
        uint32 left = r.maxTickets - r.ticketsSold;
        if (left == 0) return;
        qty = uint32(bound(qty, 1, left));
        vm.prank(actors[actorSeed % 3]);
        raffle.buyTickets(id, qty);
    }

    function draw(uint256 idSeed) external {
        if (maxId == 0) return;
        uint256 id = bound(idSeed, 1, maxId);
        vm.roll(block.number + 1);
        try raffle.drawRaffle(id) {} catch {}
    }

    function warp(uint256 secs) external {
        skip(bound(secs, 1, 2 days));
    }

    function setBlocked(uint256 actorSeed, bool b) external {
        usdc.setBlocked(actors[actorSeed % 3], b);
    }

    function claim(uint256 actorSeed) external {
        vm.prank(actors[actorSeed % 3]);
        try raffle.claim() {} catch {}
    }

    /// Toggle the treasury blocklist so fee payments randomly go direct or fall back to accruedFees.
    function setTreasuryBlocked(bool b) external {
        usdc.setBlocked(raffle.treasury(), b);
    }

    function withdrawFees(uint256 actorSeed) external {
        vm.prank(actors[actorSeed % 3]); // permissionless: any caller
        try raffle.withdrawFees() {} catch {} // reverts while the treasury is blocklisted
    }
}

contract LuckyDrawInvariantTest is Test {
    LuckyDraw internal raffle;
    MockUSDC internal usdc;
    LuckyDrawHandler internal handler;
    address internal owner = makeAddr("owner");
    address internal treasury = makeAddr("treasury");

    function setUp() public {
        vm.warp(1_000_000);
        vm.roll(100);
        usdc = new MockUSDC();
        raffle = new LuckyDraw(address(usdc), treasury, 300, owner);
        handler = new LuckyDrawHandler(raffle, usdc);
        targetContract(address(handler));
    }

    /// Fee conservation: every fee charged by a drawn raffle is either already in the treasury
    /// (direct or via withdrawFees) or still held in accruedFees. Treasury is only ever funded by fees.
    function invariant_FeesEitherInTreasuryOrAccrued() public view {
        uint256 totalFees;
        uint256 n = raffle.raffleCount();
        for (uint256 id = 1; id <= n; ++id) {
            LuckyDraw.Raffle memory r = raffle.getRaffle(id);
            if (r.status == LuckyDraw.Status.Drawn) totalFees += r.fee;
        }
        assertEq(totalFees, usdc.balanceOf(treasury) + raffle.accruedFees());
    }

    /// Conservation: contract balance == live pots + accrued (fallback) fees + deferred claims.
    /// Fees paid directly to the treasury have already left the contract.
    function invariant_BalanceEqualsLiabilities() public view {
        uint256 liabilities = raffle.accruedFees();
        uint256 n = raffle.raffleCount();
        for (uint256 id = 1; id <= n; ++id) {
            LuckyDraw.Raffle memory r = raffle.getRaffle(id);
            if (r.status == LuckyDraw.Status.Active) liabilities += r.ticketPrice * r.ticketsSold;
        }
        for (uint256 i; i < handler.actorCount(); ++i) {
            liabilities += raffle.claimable(handler.actors(i));
        }
        assertEq(usdc.balanceOf(address(raffle)), liabilities);
    }

    /// Drawn raffles: winner is a ticket holder, pot = fee + payout, ticket in range.
    function invariant_DrawnRafflesConsistent() public view {
        uint256 n = raffle.raffleCount();
        for (uint256 id = 1; id <= n; ++id) {
            LuckyDraw.Raffle memory r = raffle.getRaffle(id);
            if (r.status == LuckyDraw.Status.Drawn) {
                assertLt(r.winningTicket, r.ticketsSold);
                assertGt(raffle.ticketsOf(id, r.winner), 0);
                assertEq(r.pot, r.fee + r.payout);
                assertEq(r.pot, r.ticketPrice * r.ticketsSold);
            } else {
                assertEq(r.winner, address(0));
            }
            assertLe(r.ticketsSold, r.maxTickets);
        }
    }
}
