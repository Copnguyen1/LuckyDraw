// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {LuckyDraw} from "../LuckyDraw.sol";
import {LuckyDrawBase} from "./LuckyDraw.t.sol";

contract LuckyDrawFuzzTest is LuckyDrawBase {
    function _contains(address[] memory ps, address a) internal pure returns (bool) {
        for (uint256 i; i < ps.length; ++i) if (ps[i] == a) return true;
        return false;
    }

    /// Payout arithmetic: pot = price*sold, fee = floor(pot*bps/1e4), payout = pot-fee, no dust lost.
    function testFuzz_PayoutArithmetic(uint256 price, uint32 maxT, uint16 bps, uint32 qa, uint32 qb) public {
        price = bound(price, 10_000, 1e9); // alice/bob hold 1e15 each; max cost 1e9*1000
        maxT = uint32(bound(maxT, 2, 1000));
        bps = uint16(bound(bps, 200, 500));
        qa = uint32(bound(qa, 1, maxT - 1));
        qb = uint32(bound(qb, 1, maxT - qa));

        vm.prank(owner);
        raffle.setFeeBps(bps);
        uint256 id = _create(price, maxT, DUR);
        _buy(alice, id, qa);
        _buy(bob, id, qb);
        vm.warp(raffle.getRaffle(id).endTime);
        _nextBlock();
        uint256 balBefore = usdc.balanceOf(address(raffle));
        raffle.drawRaffle(id);

        uint256 sold = uint256(qa) + qb;
        LuckyDraw.Raffle memory r = raffle.getRaffle(id);
        assertEq(r.pot, price * sold);
        assertEq(r.fee, (price * sold * bps) / 10_000);
        assertEq(r.payout, r.pot - r.fee);
        assertEq(r.payout + r.fee, r.pot);
        assertLe(r.fee, (r.pot * 500) / 10_000);
        // fee goes straight to treasury; nothing accrues while the treasury can receive
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(treasury), r.fee);
        // pot left the contract entirely as payout + fee
        assertEq(usdc.balanceOf(address(raffle)), balBefore - r.payout - r.fee);
        assertEq(usdc.balanceOf(address(raffle)), 0);
    }

    /// Winner is always a participant, ticket < sold, and consistent with getTicketOwner.
    function testFuzz_WinnerSelection(uint8 qa, uint8 qb, uint8 qc, uint8 order, uint16 blocksAhead, bytes32 salt)
        public
    {
        uint32 a = uint32(bound(qa, 1, 100));
        uint32 b = uint32(bound(qb, 0, 100));
        uint32 c = uint32(bound(qc, 0, 100));
        uint256 id = _create(PRICE, 1000, DUR);

        // vary purchase interleaving
        if (order % 2 == 0) {
            _buy(alice, id, a);
            if (b > 0) _buy(bob, id, b);
            if (c > 0) _buy(carol, id, c);
            _buy(alice, id, 1);
        } else {
            if (c > 0) _buy(carol, id, c);
            _buy(alice, id, a);
            if (b > 0) _buy(bob, id, b);
        }
        uint32 sold = raffle.getRaffle(id).ticketsSold;

        vm.warp(raffle.getRaffle(id).endTime);
        vm.roll(block.number + 1 + bound(blocksAhead, 0, 5000));
        vm.prevrandao(salt);
        raffle.drawRaffle(id);

        LuckyDraw.Raffle memory r = raffle.getRaffle(id);
        assertLt(r.winningTicket, sold);
        assertTrue(_contains(raffle.getParticipants(id), r.winner));
        assertEq(r.winner, raffle.getTicketOwner(id, r.winningTicket));
        assertGt(raffle.ticketsOf(id, r.winner), 0);
    }

    /// Every ticket index in [0, sold) resolves to a participant whose count matches ticketsOf.
    function testFuzz_TicketOwnershipPartitionsAllTickets(uint8[6] memory qs) public {
        uint256 id = _create(PRICE, 1000, DUR);
        address[3] memory users = [alice, bob, carol];
        for (uint256 i; i < qs.length; ++i) {
            uint32 q = uint32(bound(qs[i], 1, 20));
            _buy(users[i % 3], id, q);
        }
        uint32 sold = raffle.getRaffle(id).ticketsSold;
        uint32[3] memory counted;
        for (uint256 t; t < sold; ++t) {
            address o = raffle.getTicketOwner(id, t);
            for (uint256 u; u < 3; ++u) if (users[u] == o) counted[u]++;
        }
        for (uint256 u; u < 3; ++u) assertEq(counted[u], raffle.ticketsOf(id, users[u]));
        assertEq(uint256(counted[0]) + counted[1] + counted[2], sold);
    }

    /// Buying never exceeds capacity and always costs price * quantity.
    function testFuzz_BuyCostAndCapacity(uint32 maxT, uint32 q) public {
        maxT = uint32(bound(maxT, 2, 1000));
        uint256 id = _create(PRICE, maxT, DUR);
        q = uint32(bound(q, 1, maxT));
        uint256 before_ = usdc.balanceOf(alice);
        _buy(alice, id, q);
        assertEq(before_ - usdc.balanceOf(alice), uint256(q) * PRICE);
        if (q < maxT) {
            vm.expectRevert(LuckyDraw.NotEnoughTickets.selector);
            _buy(bob, id, maxT - q + 1);
        }
    }

    /// Deferred payouts always equal the payout and are fully claimable once unblocked.
    function testFuzz_DeferredPayoutClaimable(uint32 qty, uint16 bps) public {
        qty = uint32(bound(qty, 2, 1000));
        bps = uint16(bound(bps, 200, 500));
        vm.prank(owner);
        raffle.setFeeBps(bps);
        uint256 id = _create(PRICE, qty, DUR);
        _buy(alice, id, qty);
        usdc.setBlocked(alice, true);
        _draw(id);
        uint256 pot = PRICE * qty;
        uint256 payout = pot - (pot * bps) / 10_000;
        assertEq(raffle.claimable(alice), payout);
        usdc.setBlocked(alice, false);
        uint256 b0 = usdc.balanceOf(alice);
        vm.prank(alice);
        raffle.claim();
        assertEq(usdc.balanceOf(alice) - b0, payout);
        assertEq(usdc.balanceOf(address(raffle)), raffle.accruedFees());
    }
}
