// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {LuckyDraw} from "../LuckyDraw.sol";
import {LuckyDrawBase} from "./LuckyDraw.t.sol";

contract LuckyDrawAdminTest is LuckyDrawBase {
    function _unauth(address who) internal pure returns (bytes memory) {
        return abi.encodeWithSelector(Ownable.OwnableUnauthorizedAccount.selector, who);
    }

    /// Single-buyer sold-out raffle so the winner is known to be alice.
    function _soloFilled() internal returns (uint256 id) {
        id = _createDefault();
        _buy(alice, id, MAXT);
    }

    // ---------------------------------------------------------------- deferred payout / claim
    function test_Deferred_RevertingTransferBecomesClaimable() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(alice, true);
        uint256 balBefore = usdc.balanceOf(alice);

        _nextBlock();
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.PayoutDeferred(id, alice, 9_700_000);
        raffle.drawRaffle(id); // must NOT revert

        assertEq(uint8(raffle.getRaffle(id).status), uint8(LuckyDraw.Status.Drawn));
        assertEq(raffle.claimable(alice), 9_700_000);
        assertEq(usdc.balanceOf(alice), balBefore);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(usdc.balanceOf(address(raffle)), 9_700_000); // only the deferred claim remains
    }

    function test_Deferred_FalseReturningTransferBecomesClaimable() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(alice, true);
        usdc.setReturnFalse(true);
        _draw(id);
        assertEq(raffle.claimable(alice), 9_700_000);
    }

    function test_Claim_AfterUnblockPaysAndEmits() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(alice, true);
        _draw(id);

        vm.prank(alice);
        vm.expectRevert(); // still blocklisted: transfer reverts, liability restored
        raffle.claim();
        assertEq(raffle.claimable(alice), 9_700_000);

        usdc.setBlocked(alice, false);
        uint256 balBefore = usdc.balanceOf(alice);
        vm.expectEmit(true, false, false, true, address(raffle));
        emit LuckyDraw.Claimed(alice, 9_700_000);
        vm.prank(alice);
        raffle.claim();
        assertEq(usdc.balanceOf(alice), balBefore + 9_700_000);
        assertEq(raffle.claimable(alice), 0);
        assertEq(usdc.balanceOf(address(raffle)), raffle.accruedFees());

        vm.prank(alice);
        vm.expectRevert(LuckyDraw.NothingToClaim.selector);
        raffle.claim();
    }

    function test_Claim_RevertsWhenNothingToClaim() public {
        vm.prank(bob);
        vm.expectRevert(LuckyDraw.NothingToClaim.selector);
        raffle.claim();
    }

    function test_Claim_WorksWhilePaused() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(alice, true);
        _draw(id);
        usdc.setBlocked(alice, false);
        vm.prank(owner);
        raffle.pause();
        vm.prank(alice);
        raffle.claim();
        assertEq(raffle.claimable(alice), 0);
    }

    function test_Deferred_AccumulatesAcrossRaffles() public {
        uint256 a = _soloFilled();
        uint256 b = _soloFilled();
        usdc.setBlocked(alice, true);
        _nextBlock();
        raffle.drawRaffle(a);
        raffle.drawRaffle(b);
        assertEq(raffle.claimable(alice), 2 * 9_700_000);
    }

    // ---------------------------------------------------------------- fees
    // withdrawFees only has funds when a direct fee transfer failed, so these tests
    // block the treasury at draw time (fallback to accruedFees) and unblock before withdrawing.
    function test_WithdrawFees_SendsAccruedToTreasury() public {
        uint256 id = _createDefault();
        _fill(id);
        usdc.setBlocked(treasury, true);
        _draw(id);
        usdc.setBlocked(treasury, false);
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(usdc.balanceOf(treasury), 0);
        vm.expectEmit(true, false, false, true, address(raffle));
        emit LuckyDraw.FeesWithdrawn(treasury, 300_000);
        vm.prank(owner);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
    }

    function test_WithdrawFees_NonOwnerPaysTreasury() public {
        uint256 id = _createDefault();
        _fill(id);
        usdc.setBlocked(treasury, true);
        _draw(id);
        usdc.setBlocked(treasury, false);
        uint256 callerBefore = usdc.balanceOf(carol);
        vm.expectEmit(true, false, false, true, address(raffle));
        emit LuckyDraw.FeesWithdrawn(treasury, 300_000);
        vm.prank(carol);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(usdc.balanceOf(carol), callerBefore); // caller gets nothing
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
    }

    function test_WithdrawFees_RevertsWhileTreasuryStillBlockedKeepsAccounting() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        _draw(id);
        vm.prank(bob);
        vm.expectRevert();
        raffle.withdrawFees();
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(usdc.balanceOf(address(raffle)), 300_000);
    }

    function test_WithdrawFees_SecondCallIsZeroNoop() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        _draw(id);
        usdc.setBlocked(treasury, false);
        vm.prank(alice);
        raffle.withdrawFees();
        vm.expectEmit(true, false, false, true, address(raffle));
        emit LuckyDraw.FeesWithdrawn(treasury, 0);
        vm.prank(bob);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 300_000);
    }

    function test_WithdrawFees_AccumulatesAcrossRafflesWithDifferentFees() public {
        uint256 a = _createDefault();
        vm.prank(owner);
        raffle.setFeeBps(500);
        uint256 b = _createDefault();
        _fill(a);
        _fill(b);
        usdc.setBlocked(treasury, true);
        _nextBlock();
        raffle.drawRaffle(a);
        raffle.drawRaffle(b);
        usdc.setBlocked(treasury, false);
        assertEq(raffle.accruedFees(), 300_000 + 500_000);
        vm.prank(owner);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 800_000);
    }

    function test_WithdrawFees_DoesNotTouchPlayerFunds() public {
        uint256 a = _soloFilled(); // drawn -> fee 300k accrued (treasury blocked)
        usdc.setBlocked(treasury, true);
        _draw(a);
        usdc.setBlocked(treasury, false);
        assertEq(raffle.accruedFees(), 300_000);
        uint256 b = _createDefault();
        _buy(bob, b, 4); // active pot 4e6
        vm.prank(owner);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(address(raffle)), 4e6);
    }

    function test_WithdrawFees_ZeroAmountIsNoop() public {
        uint256 before = usdc.balanceOf(address(raffle));
        vm.expectEmit(true, false, false, true, address(raffle));
        emit LuckyDraw.FeesWithdrawn(treasury, 0);
        vm.prank(carol);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 0);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), before);
    }

    function test_WithdrawFees_NoopDoesNotTouchActivePot() public {
        uint256 id = _createDefault();
        _buy(bob, id, 4);
        vm.prank(alice);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 0);
        assertEq(usdc.balanceOf(address(raffle)), 4e6);
    }

    function test_WithdrawFees_WorksWhilePausedByAnyone() public {
        uint256 id = _createDefault();
        _fill(id);
        usdc.setBlocked(treasury, true);
        _draw(id);
        usdc.setBlocked(treasury, false);
        vm.prank(owner);
        raffle.pause();
        vm.prank(bob);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 300_000);
    }

    function test_WithdrawFees_DoesNotTouchDeferredClaims() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        usdc.setBlocked(alice, true);
        _draw(id);
        usdc.setBlocked(treasury, false);
        vm.prank(bob);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(raffle.claimable(alice), 9_700_000);
        assertEq(usdc.balanceOf(address(raffle)), 9_700_000);
    }

    function test_SetFeeBps_UpdatesAndEmits() public {
        vm.expectEmit(false, false, false, true, address(raffle));
        emit LuckyDraw.FeeBpsUpdated(300, 450);
        vm.prank(owner);
        raffle.setFeeBps(450);
        assertEq(raffle.feeBps(), 450);
    }

    function test_SetFeeBps_Boundaries() public {
        vm.startPrank(owner);
        raffle.setFeeBps(200);
        assertEq(raffle.feeBps(), 200);
        raffle.setFeeBps(500);
        assertEq(raffle.feeBps(), 500);
        vm.expectRevert(LuckyDraw.FeeTooHigh.selector);
        raffle.setFeeBps(501);
        vm.expectRevert(LuckyDraw.FeeTooLow.selector);
        raffle.setFeeBps(199);
        vm.expectRevert(LuckyDraw.FeeTooLow.selector);
        raffle.setFeeBps(0);
        vm.stopPrank();
    }

    function test_SetFeeBps_RevertsNonOwner() public {
        vm.prank(alice);
        vm.expectRevert(_unauth(alice));
        raffle.setFeeBps(250);
    }

    function test_Treasury_IsImmutableAndEqualsConstructorArg() public {
        assertEq(raffle.treasury(), treasury);
        // No setter exists: the selector is not dispatched (no fallback) for owner or others.
        bytes memory call = abi.encodeWithSignature("setTreasury(address)", bob);
        vm.prank(owner);
        (bool ok,) = address(raffle).call(call);
        assertFalse(ok);
        vm.prank(alice);
        (ok,) = address(raffle).call(call);
        assertFalse(ok);
        assertEq(raffle.treasury(), treasury);
        // Different constructor arg is reflected.
        LuckyDraw other = new LuckyDraw(address(usdc), bob, FEE, owner);
        assertEq(other.treasury(), bob);
    }

    function test_Treasury_UnchangedByOwnershipTransfer() public {
        vm.prank(owner);
        raffle.transferOwnership(bob);
        assertEq(raffle.treasury(), treasury);
    }

    // ---------------------------------------------------------------- ownership / pause
    function test_RenounceOwnership_AlwaysReverts() public {
        vm.prank(owner);
        vm.expectRevert(LuckyDraw.OwnershipRenunciationDisabled.selector);
        raffle.renounceOwnership();
        assertEq(raffle.owner(), owner);
        vm.prank(alice);
        vm.expectRevert(_unauth(alice));
        raffle.renounceOwnership();
    }

    function test_TransferOwnership_Works() public {
        vm.prank(owner);
        raffle.transferOwnership(bob);
        assertEq(raffle.owner(), bob);
        vm.prank(bob);
        raffle.setFeeBps(250);
        vm.prank(owner);
        vm.expectRevert(_unauth(owner));
        raffle.setFeeBps(260);
    }

    function test_PauseUnpause_OnlyOwner() public {
        vm.prank(alice);
        vm.expectRevert(_unauth(alice));
        raffle.pause();
        vm.prank(owner);
        raffle.pause();
        assertTrue(raffle.paused());
        vm.prank(alice);
        vm.expectRevert(_unauth(alice));
        raffle.unpause();
        vm.prank(owner);
        raffle.unpause();
        assertFalse(raffle.paused());
    }

    function test_Pause_BlocksCreateAndBuy() public {
        uint256 id = _createDefault();
        vm.prank(owner);
        raffle.pause();
        vm.expectRevert(Pausable.EnforcedPause.selector);
        _createDefault();
        vm.expectRevert(Pausable.EnforcedPause.selector);
        _buy(alice, id, 1);
        vm.prank(owner);
        raffle.unpause();
        _buy(alice, id, 1);
        assertEq(raffle.getRaffle(id).ticketsSold, 1);
    }

    function test_Pause_DoesNotBlockDraw() public {
        uint256 id = _createDefault();
        _fill(id);
        uint256 empty = _createDefault();
        vm.prank(owner);
        raffle.pause();
        _nextBlock();
        raffle.drawRaffle(id);
        assertEq(uint8(raffle.getRaffle(id).status), uint8(LuckyDraw.Status.Drawn));
        vm.warp(raffle.getRaffle(empty).endTime);
        raffle.drawRaffle(empty);
        assertEq(uint8(raffle.getRaffle(empty).status), uint8(LuckyDraw.Status.Cancelled));
    }

    function test_Pause_DoublePauseReverts() public {
        vm.startPrank(owner);
        raffle.pause();
        vm.expectRevert(Pausable.EnforcedPause.selector);
        raffle.pause();
        raffle.unpause();
        vm.expectRevert(Pausable.ExpectedPause.selector);
        raffle.unpause();
        vm.stopPrank();
    }
}
