// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Vm} from "forge-std/Vm.sol";
import {LuckyDraw} from "../LuckyDraw.sol";
import {LuckyDrawBase} from "./LuckyDraw.t.sol";

/// Direct-to-treasury fee payment at draw time, with accruedFees as the fallback.
contract LuckyDrawFeesTest is LuckyDrawBase {
    address internal newTreasury = makeAddr("newTreasury");

    function _soloFilled() internal returns (uint256 id) {
        id = _createDefault();
        _buy(alice, id, MAXT);
    }

    // ---------------------------------------------------------------- direct payment
    function test_Fee_LandsInTreasuryAtDrawAndEmitsFeeSent() public {
        uint256 id = _soloFilled();
        _nextBlock();
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.FeeSent(id, treasury, 300_000);
        raffle.drawRaffle(id);

        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
        assertEq(raffle.getRaffle(id).fee, 300_000);
    }

    function test_Fee_FeeSentEmittedBeforePayoutAndRaffleDrawn() public {
        uint256 id = _soloFilled();
        _nextBlock();
        vm.recordLogs();
        raffle.drawRaffle(id);
        Vm.Log[] memory logs = vm.getRecordedLogs();
        bytes32 feeSig = LuckyDraw.FeeSent.selector;
        bytes32 paySig = LuckyDraw.PayoutSent.selector;
        bytes32 drawnSig = LuckyDraw.RaffleDrawn.selector;
        int256 feeAt = -1;
        int256 payAt = -1;
        int256 drawnAt = -1;
        uint256 feeCount;
        for (uint256 i; i < logs.length; ++i) {
            if (logs[i].emitter != address(raffle)) continue;
            if (logs[i].topics[0] == feeSig) {
                feeAt = int256(i);
                ++feeCount;
            } else if (logs[i].topics[0] == paySig) {
                payAt = int256(i);
            } else if (logs[i].topics[0] == drawnSig) {
                drawnAt = int256(i);
            }
        }
        assertEq(feeCount, 1);
        assertTrue(feeAt >= 0 && feeAt < payAt && payAt < drawnAt);
    }

    function test_Fee_NoFeeSentOnCancelledEmptyRaffle() public {
        uint256 id = _createDefault();
        vm.warp(raffle.getRaffle(id).endTime);
        vm.recordLogs();
        raffle.drawRaffle(id);
        Vm.Log[] memory logs = vm.getRecordedLogs();
        for (uint256 i; i < logs.length; ++i) {
            assertTrue(logs[i].topics[0] != LuckyDraw.FeeSent.selector);
        }
        assertEq(usdc.balanceOf(treasury), 0);
    }

    function test_Fee_AccumulatesInTreasuryAcrossDraws() public {
        uint256 a = _soloFilled();
        uint256 b = _soloFilled();
        _nextBlock();
        raffle.drawRaffle(a);
        raffle.drawRaffle(b);
        assertEq(usdc.balanceOf(treasury), 600_000);
        assertEq(raffle.accruedFees(), 0);
    }

    function test_Fee_DirectPaymentIndependentOfDeferredWinner() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(alice, true); // winner blocked -> deferred; treasury fine
        _draw(id);
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(raffle.accruedFees(), 0);
        assertEq(raffle.claimable(alice), 9_700_000);
        assertEq(usdc.balanceOf(address(raffle)), 9_700_000);
    }

    // ---------------------------------------------------------------- fallback to accruedFees
    function test_Fee_RevertingTreasuryFallsBackToAccruedWithoutBlockingDraw() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true); // transfer reverts
        _nextBlock();

        vm.recordLogs();
        raffle.drawRaffle(id); // must not revert
        Vm.Log[] memory logs = vm.getRecordedLogs();
        for (uint256 i; i < logs.length; ++i) {
            assertTrue(logs[i].topics[0] != LuckyDraw.FeeSent.selector);
        }

        assertEq(uint8(raffle.getRaffle(id).status), uint8(LuckyDraw.Status.Drawn));
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(usdc.balanceOf(treasury), 0);
        assertEq(usdc.balanceOf(address(raffle)), 300_000);
        // winner (alice) still got paid
        assertEq(raffle.claimable(alice), 0);
    }

    function test_Fee_FalseReturningTreasuryFallsBackToAccrued() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        usdc.setReturnFalse(true);
        _draw(id);
        assertEq(uint8(raffle.getRaffle(id).status), uint8(LuckyDraw.Status.Drawn));
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(usdc.balanceOf(treasury), 0);
    }

    function test_Fee_BlockedTreasuryAndBlockedWinnerBothFallBack() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        usdc.setBlocked(alice, true);
        _draw(id);
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(raffle.claimable(alice), 9_700_000);
        assertEq(usdc.balanceOf(address(raffle)), 10e6);
    }

    function test_Fee_RecoversToSameTreasuryAfterUnblockByAnyCaller() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        _draw(id);
        assertEq(raffle.accruedFees(), 300_000);

        // treasury still blocked: withdraw reverts (for anyone) and leaves accounting intact
        vm.prank(carol);
        vm.expectRevert();
        raffle.withdrawFees();
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(usdc.balanceOf(address(raffle)), 300_000);

        usdc.setBlocked(treasury, false);
        vm.expectEmit(true, false, false, true, address(raffle));
        emit LuckyDraw.FeesWithdrawn(treasury, 300_000);
        vm.prank(carol);
        raffle.withdrawFees();

        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
    }

    function test_Fee_FalseReturningTreasuryWithdrawRevertsThenRecovers() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        usdc.setReturnFalse(true);
        _draw(id);
        vm.prank(bob);
        vm.expectRevert(); // SafeERC20 rejects false return
        raffle.withdrawFees();
        assertEq(raffle.accruedFees(), 300_000);
        usdc.setBlocked(treasury, false);
        vm.prank(bob);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 300_000);
    }

    function test_Fee_AlwaysReachesTreasuryBothPaths() public {
        uint256 a = _soloFilled();
        uint256 b = _soloFilled();
        _nextBlock();
        raffle.drawRaffle(a); // direct
        usdc.setBlocked(treasury, true);
        raffle.drawRaffle(b); // fallback
        usdc.setBlocked(treasury, false);
        vm.prank(carol);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), 600_000);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
        assertEq(raffle.treasury(), treasury);
    }

    function test_Fee_WithdrawerCannotRedirectOrCaptureFees() public {
        uint256 id = _soloFilled();
        usdc.setBlocked(treasury, true);
        _draw(id);
        usdc.setBlocked(treasury, false);
        uint256 bobBefore = usdc.balanceOf(bob);
        vm.prank(bob);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(bob), bobBefore);
        assertEq(usdc.balanceOf(treasury), 300_000);
    }

    function test_Fee_FallbackThenLaterDirectPaymentsDoNotMix() public {
        uint256 a = _soloFilled();
        usdc.setBlocked(treasury, true);
        _draw(a); // accrues
        usdc.setBlocked(treasury, false);
        uint256 b = _soloFilled();
        _draw(b); // direct
        assertEq(raffle.accruedFees(), 300_000);
        assertEq(usdc.balanceOf(treasury), 300_000);
        assertEq(usdc.balanceOf(address(raffle)), 300_000);
    }

    // ---------------------------------------------------------------- immutable treasury
    function test_Treasury_FeesAlwaysGoToConstructorTreasuryAcrossDraws() public {
        uint256 a = _soloFilled();
        uint256 b = _soloFilled();
        _nextBlock();
        raffle.drawRaffle(a);
        vm.prank(owner);
        raffle.transferOwnership(newTreasury); // ownership change must not affect fee wallet
        vm.expectEmit(true, true, false, true, address(raffle));
        emit LuckyDraw.FeeSent(b, treasury, 300_000);
        raffle.drawRaffle(b);
        assertEq(usdc.balanceOf(treasury), 600_000);
        assertEq(usdc.balanceOf(newTreasury), 0);
        assertEq(raffle.treasury(), treasury);
    }

    // ---------------------------------------------------------------- fuzz
    function testFuzz_Fee_DirectOrFallbackConservesPot(uint32 qty, uint16 bps, bool blockTreasury) public {
        qty = uint32(bound(qty, 2, 1000));
        bps = uint16(bound(bps, 200, 500));
        vm.prank(owner);
        raffle.setFeeBps(bps);
        uint256 id = _create(PRICE, qty, DUR);
        _buy(bob, id, qty); // bob is sole holder -> winner
        usdc.setBlocked(treasury, blockTreasury);
        _draw(id);

        uint256 pot = PRICE * qty;
        uint256 fee = (pot * bps) / 10_000;
        assertEq(usdc.balanceOf(bob), 1e15 - pot + (pot - fee));
        if (blockTreasury) {
            assertEq(raffle.accruedFees(), fee);
            assertEq(usdc.balanceOf(treasury), 0);
            assertEq(usdc.balanceOf(address(raffle)), fee);
        } else {
            assertEq(raffle.accruedFees(), 0);
            assertEq(usdc.balanceOf(treasury), fee);
            assertEq(usdc.balanceOf(address(raffle)), 0);
        }
        // fee always reaches the treasury once it can receive
        usdc.setBlocked(treasury, false);
        vm.prank(carol);
        raffle.withdrawFees();
        assertEq(usdc.balanceOf(treasury), fee);
        assertEq(raffle.accruedFees(), 0);
        assertEq(usdc.balanceOf(address(raffle)), 0);
    }
}
