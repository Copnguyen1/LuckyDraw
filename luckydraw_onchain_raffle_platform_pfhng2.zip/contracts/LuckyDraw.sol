// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/**
 * @title LuckyDraw
 * @notice Onchain USDC raffle demonstration for Arc Testnet, with zero-based tickets.
 * @dev Intended for standard, non-rebasing, non-fee-on-transfer, six-decimal USDC.
 * Arc Testnet USDC is 0x3600000000000000000000000000000000000000; supply it
 * explicitly to the constructor. No native receive or fallback function is provided.
 *
 * SECURITY / LIMITATIONS:
 * Blockhash randomness is for demos only and can be manipulated by validators/block
 * producers. The last-ticket buyer or a block producer may bias the outcome through
 * purchase timing, transaction ordering, or draw timing. Do not use for real value.
 * Drawing is permissionless but requires a transaction; no automatic keeper exists.
 * Pausing only stops creation and purchases, never drawing or claiming. Failed winner
 * transfers become pull claims; a blocklisted winner may remain unable to claim until
 * the token restriction is lifted. Claims cannot be redirected by the owner.
 * The owner controls future fees and sales pausing, but cannot change the (immutable)
 * fee treasury, cancel funded raffles or withdraw player liabilities. No refunds are provided;
 * any nonempty raffle can be drawn after expiry, including a single-ticket raffle.
 */
contract LuckyDraw is Pausable, Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint16 public constant MAX_FEE_BPS = 500;
    /// @notice Minimum platform fee in basis points (2%).
    uint16 public constant MIN_FEE_BPS = 200;
    uint256 public constant BPS = 10_000;
    uint64 public constant MIN_DURATION = 60 seconds;
    uint64 public constant MAX_DURATION = 30 days;
    uint32 public constant MIN_TICKETS = 2;
    uint32 public constant MAX_TICKETS = 1000;
    uint256 public constant MIN_TICKET_PRICE = 10_000;

    enum Status { Active, Drawn, Cancelled }
    enum Phase { Active, ReadyToDraw, Drawn, Cancelled, ExpiredEmpty }

    struct Raffle {
        address creator;
        uint256 ticketPrice;
        uint32 maxTickets;
        uint32 ticketsSold;
        uint64 createdAt;
        uint64 endTime;
        uint64 drawnAt;
        uint16 feeBps;
        Status status;
        address winner;
        uint32 winningTicket;
        uint256 pot;
        uint256 fee;
        uint256 payout;
        uint256 drawBlock;
        uint256 lastPurchaseBlock;
    }

    /// @dev Each entry owns indices from the previous endIndex up to endIndex - 1.
    struct Entry {
        address buyer;
        uint32 endIndex;
    }

    IERC20 public immutable usdc;
    /// @notice Immutable platform fee wallet. All platform fees are sent here.
    address public immutable treasury;
    uint16 public feeBps;
    uint256 public accruedFees;
    uint256 public nextRaffleId = 1;
    mapping(address => uint256) public claimable;
    mapping(uint256 => mapping(address => uint32)) public ticketsOf;

    mapping(uint256 => Raffle) private _raffles;
    mapping(uint256 => Entry[]) private _entries;
    mapping(uint256 => address[]) private _participants;
    mapping(address => uint256[]) private _createdRaffles;
    mapping(address => uint256[]) private _joinedRaffles;

    error ZeroAddress();
    error FeeTooHigh();
    error FeeTooLow();
    error InvalidTicketPrice();
    error InvalidMaxTickets();
    error InvalidDuration();
    error TimestampOverflow();
    error RaffleNotFound(uint256 id);
    error RaffleNotActive(uint256 id);
    error SalesEnded(uint256 id);
    error InvalidQuantity();
    error NotEnoughTickets();
    error NotReadyToDraw();
    error SameBlockAsLastPurchase();
    error InvalidTicketIndex();
    error NothingToClaim();
    error OwnershipRenunciationDisabled();

    event RaffleCreated(uint256 indexed id, address indexed creator, uint256 ticketPrice, uint32 maxTickets, uint64 endTime, uint16 feeBps);
    event TicketsPurchased(uint256 indexed id, address indexed buyer, uint32 quantity, uint32 firstTicket, uint256 totalPaid, uint32 ticketsSold);
    event RaffleCancelled(uint256 indexed id);
    event PayoutDeferred(uint256 indexed id, address indexed winner, uint256 payout);
    event PayoutSent(uint256 indexed id, address indexed winner, uint256 payout);
    event RaffleDrawn(uint256 indexed id, address indexed winner, uint32 winningTicket, uint256 pot, uint256 fee, uint256 payout, uint256 drawBlock, address indexed caller);
    event FeeSent(uint256 indexed id, address indexed treasury, uint256 amount);
    event Claimed(address indexed user, uint256 amount);
    event FeeBpsUpdated(uint16 oldFeeBps, uint16 newFeeBps);
    event FeesWithdrawn(address indexed treasury, uint256 amount);

    /**
     * @notice Initializes the token, treasury, future-raffle fee, and owner.
     * @param usdc_ Standard six-decimal USDC contract address.
     * @param treasury_ Recipient of protocol fees.
     * @param feeBps_ Initial fee in basis points, at most 500.
     * @param owner_ Initial owner; all address arguments must be nonzero.
     */
    constructor(address usdc_, address treasury_, uint16 feeBps_, address owner_) Ownable(owner_) {
        if (usdc_ == address(0) || treasury_ == address(0) || owner_ == address(0)) revert ZeroAddress();
        if (feeBps_ > MAX_FEE_BPS) revert FeeTooHigh();
        if (feeBps_ < MIN_FEE_BPS) revert FeeTooLow();
        usdc = IERC20(usdc_);
        treasury = treasury_;
        feeBps = feeBps_;
    }

    /**
     * @notice Creates a raffle and snapshots its fee rate; requires unpaused sales.
     * @param ticketPrice Price per ticket in six-decimal USDC base units.
     * @param maxTickets Maximum tickets, between 2 and 1000 inclusive.
     * @param duration Sale duration in seconds, between 60 seconds and 30 days.
     * @return id The newly allocated raffle ID, starting at 1.
     */
    function createRaffle(uint256 ticketPrice, uint32 maxTickets, uint64 duration)
        external whenNotPaused returns (uint256 id)
    {
        if (ticketPrice < MIN_TICKET_PRICE) revert InvalidTicketPrice();
        if (maxTickets < MIN_TICKETS || maxTickets > MAX_TICKETS) revert InvalidMaxTickets();
        if (duration < MIN_DURATION || duration > MAX_DURATION) revert InvalidDuration();
        uint256 end = block.timestamp + duration;
        if (end > type(uint64).max) revert TimestampOverflow();

        id = nextRaffleId++;
        Raffle storage raffle = _raffles[id];
        raffle.creator = msg.sender;
        raffle.ticketPrice = ticketPrice;
        raffle.maxTickets = maxTickets;
        raffle.createdAt = uint64(block.timestamp);
        raffle.endTime = uint64(end);
        raffle.feeBps = feeBps;
        _createdRaffles[msg.sender].push(id);
        emit RaffleCreated(id, msg.sender, ticketPrice, maxTickets, uint64(end), raffle.feeBps);
    }

    /**
     * @notice Buys consecutive zero-based tickets using a prior USDC allowance.
     * @param id Existing, active raffle whose sale has not expired.
     * @param quantity Nonzero number of remaining tickets to purchase.
     * @dev Records all effects before transferring tokens; failed payment reverts them.
     */
    function buyTickets(uint256 id, uint32 quantity) external nonReentrant whenNotPaused {
        Raffle storage raffle = _requireRaffle(id);
        if (raffle.status != Status.Active) revert RaffleNotActive(id);
        if (block.timestamp >= raffle.endTime) revert SalesEnded(id);
        if (quantity == 0) revert InvalidQuantity();
        if (quantity > raffle.maxTickets - raffle.ticketsSold) revert NotEnoughTickets();

        uint32 firstTicket = raffle.ticketsSold;
        uint32 sold = firstTicket + quantity;
        uint256 totalPaid = raffle.ticketPrice * quantity;
        raffle.ticketsSold = sold;
        raffle.lastPurchaseBlock = block.number;

        if (ticketsOf[id][msg.sender] == 0) {
            _participants[id].push(msg.sender);
            _joinedRaffles[msg.sender].push(id);
        }
        ticketsOf[id][msg.sender] += quantity;
        Entry[] storage entries = _entries[id];
        uint256 length = entries.length;
        if (length != 0 && entries[length - 1].buyer == msg.sender) {
            entries[length - 1].endIndex = sold;
        } else {
            entries.push(Entry({buyer: msg.sender, endIndex: sold}));
        }

        usdc.safeTransferFrom(msg.sender, address(this), totalPaid);
        emit TicketsPurchased(id, msg.sender, quantity, firstTicket, totalPaid, sold);
    }

    /**
     * @notice Draws a full or expired raffle, or closes an expired empty raffle.
     * @param id Existing active raffle ID.
     * @dev Available while paused. A nonempty draw must follow the last purchase block.
     * Demo-only blockhash randomness is manipulable; never use this for real value.
     * Failed or false-returning payouts become claimable without reverting the draw.
     */
    function drawRaffle(uint256 id) external nonReentrant {
        Raffle storage raffle = _requireRaffle(id);
        if (raffle.status != Status.Active) revert RaffleNotActive(id);
        uint32 sold = raffle.ticketsSold;
        if (sold != raffle.maxTickets && block.timestamp < raffle.endTime) revert NotReadyToDraw();
        if (sold == 0) {
            raffle.status = Status.Cancelled;
            emit RaffleCancelled(id);
            return;
        }
        if (block.number <= raffle.lastPurchaseBlock) revert SameBlockAsLastPurchase();

        uint256 seed = uint256(keccak256(abi.encodePacked(blockhash(block.number - 1), id, sold, address(this))));
        uint32 winningTicket = uint32(seed % sold);
        address winner = _ticketOwner(id, winningTicket);
        uint256 pot = raffle.ticketPrice * sold;
        uint256 fee = pot * raffle.feeBps / BPS;
        uint256 payout = pot - fee;
        if (block.timestamp > type(uint64).max) revert TimestampOverflow();

        raffle.status = Status.Drawn;
        raffle.winner = winner;
        raffle.winningTicket = winningTicket;
        raffle.pot = pot;
        raffle.fee = fee;
        raffle.payout = payout;
        raffle.drawnAt = uint64(block.timestamp);
        raffle.drawBlock = block.number;

        // Platform fee goes straight to the treasury. If that transfer fails, it is held in
        // accruedFees so the draw can never be blocked; anyone can later call withdrawFees().
        if (fee > 0) {
            bool feeSent;
            try IERC20(usdc).transfer(treasury, fee) returns (bool ok) {
                feeSent = ok;
            } catch {
                feeSent = false;
            }
            if (feeSent) {
                emit FeeSent(id, treasury, fee);
            } else {
                accruedFees += fee;
            }
        }

        bool sent;
        try IERC20(usdc).transfer(winner, payout) returns (bool ok) {
            sent = ok;
        } catch {
            sent = false;
        }
        if (sent) {
            emit PayoutSent(id, winner, payout);
        } else {
            claimable[winner] += payout;
            emit PayoutDeferred(id, winner, payout);
        }
        emit RaffleDrawn(id, winner, winningTicket, pot, fee, payout, block.number, msg.sender);
    }

    /**
     * @notice Claims all deferred winnings to the caller, even while paused.
     * @dev Zeros the liability before safeTransfer; a failed transfer restores it by revert.
     */
    function claim() external nonReentrant {
        uint256 amount = claimable[msg.sender];
        if (amount == 0) revert NothingToClaim();
        claimable[msg.sender] = 0;
        usdc.safeTransfer(msg.sender, amount);
        emit Claimed(msg.sender, amount);
    }

    /**
     * @notice Changes the fee for future raffles only; callable only by the owner.
     * @param newFeeBps New fee, at most MAX_FEE_BPS.
     */
    function setFeeBps(uint16 newFeeBps) external onlyOwner {
        if (newFeeBps > MAX_FEE_BPS) revert FeeTooHigh();
        if (newFeeBps < MIN_FEE_BPS) revert FeeTooLow();
        uint16 previous = feeBps;
        feeBps = newFeeBps;
        emit FeeBpsUpdated(previous, newFeeBps);
    }

    /// @notice Sends fees that could not be paid at draw time to the immutable treasury; callable by anyone, also while paused.
    /// @dev No player pot or deferred claim is included in accruedFees.
    function withdrawFees() external nonReentrant {
        uint256 amount = accruedFees;
        address recipient = treasury;
        accruedFees = 0;
        usdc.safeTransfer(recipient, amount);
        emit FeesWithdrawn(recipient, amount);
    }

    /// @notice Owner-only pause of raffle creation and ticket sales, not draws or claims.
    function pause() public onlyOwner {
        _pause();
    }

    /// @notice Owner-only resumption of raffle creation and ticket sales.
    function unpause() public onlyOwner {
        _unpause();
    }

    /// @notice Always reverts: ownership may be transferred but never renounced.
    function renounceOwnership() public override onlyOwner {
        revert OwnershipRenunciationDisabled();
    }

    /**
     * @notice Returns a raffle's stored fields, reverting for nonexistent IDs.
     * @param id Raffle ID.
     * @return raffle Stored raffle data; active pots are computed only upon drawing.
     */
    function getRaffle(uint256 id) external view returns (Raffle memory raffle) {
        return _requireRaffle(id);
    }

    /**
     * @notice Returns consecutive existing raffles starting at fromId, clamped at the end.
     * @param fromId First ID; zero or an ID beyond the last raffle returns an empty array.
     * @param count Maximum results; zero returns an empty array.
     * @return raffles Stored raffles in ascending ID order.
     */
    function getRaffles(uint256 fromId, uint256 count) external view returns (Raffle[] memory raffles) {
        if (fromId == 0 || fromId >= nextRaffleId || count == 0) return new Raffle[](0);
        uint256 available = nextRaffleId - fromId;
        if (count > available) count = available;
        raffles = new Raffle[](count);
        for (uint256 i; i < count; ++i) {
            raffles[i] = _raffles[fromId + i];
        }
    }

    /// @notice Returns the total number of created raffles, including closed raffles.
    /// @return count Number of allocated raffle IDs.
    function raffleCount() external view returns (uint256 count) {
        return nextRaffleId - 1;
    }

    /// @notice Returns unique buyers in first-purchase order; reverts for nonexistent IDs.
    /// @param id Raffle ID.
    /// @return participants Unique participants.
    function getParticipants(uint256 id) external view returns (address[] memory participants) {
        _requireRaffle(id);
        return _participants[id];
    }

    /// @notice Returns the unique buyer count; reverts for nonexistent IDs.
    /// @param id Raffle ID.
    /// @return count Number of unique buyers.
    function participantCount(uint256 id) external view returns (uint256 count) {
        _requireRaffle(id);
        return _participants[id].length;
    }

    /// @notice Resolves a sold, zero-based ticket using binary search over purchase ranges.
    /// @param id Raffle ID; nonexistent IDs revert.
    /// @param ticketIndex Ticket index strictly below ticketsSold; otherwise reverts.
    /// @return buyer Address owning that ticket.
    function getTicketOwner(uint256 id, uint256 ticketIndex) external view returns (address buyer) {
        Raffle storage raffle = _requireRaffle(id);
        if (ticketIndex >= raffle.ticketsSold) revert InvalidTicketIndex();
        return _ticketOwner(id, ticketIndex);
    }

    /// @notice Returns raffle IDs created and joined by a user, in insertion order.
    /// @param user Address to query.
    /// @return created IDs created by the user.
    /// @return joined IDs joined by the user, with no duplicates.
    function getUserRaffles(address user) external view returns (uint256[] memory created, uint256[] memory joined) {
        return (_createdRaffles[user], _joinedRaffles[user]);
    }

    /// @notice Returns derived phase: Active=0, ReadyToDraw=1, Drawn=2, Cancelled=3, ExpiredEmpty=4.
    /// @param id Raffle ID; nonexistent IDs revert.
    /// @return phase Current derived phase, independent of the global pause state.
    function getStatus(uint256 id) external view returns (Phase phase) {
        Raffle storage raffle = _requireRaffle(id);
        if (raffle.status == Status.Drawn) return Phase.Drawn;
        if (raffle.status == Status.Cancelled) return Phase.Cancelled;
        if (block.timestamp >= raffle.endTime) {
            return raffle.ticketsSold == 0 ? Phase.ExpiredEmpty : Phase.ReadyToDraw;
        }
        if (raffle.ticketsSold == raffle.maxTickets) return Phase.ReadyToDraw;
        return Phase.Active;
    }

    /// @notice Returns seconds until the sale deadline, or zero at/after the deadline.
    /// @param id Raffle ID; nonexistent IDs revert.
    /// @return remaining Time to the deadline, even if already drawn early through sellout.
    function timeRemaining(uint256 id) external view returns (uint256 remaining) {
        Raffle storage raffle = _requireRaffle(id);
        return block.timestamp >= raffle.endTime ? 0 : raffle.endTime - block.timestamp;
    }

    function _requireRaffle(uint256 id) private view returns (Raffle storage raffle) {
        if (id == 0 || id >= nextRaffleId) revert RaffleNotFound(id);
        return _raffles[id];
    }

    /// @dev Caller guarantees ticketIndex < ticketsSold, so an owning range exists.
    function _ticketOwner(uint256 id, uint256 ticketIndex) private view returns (address) {
        Entry[] storage entries = _entries[id];
        uint256 low;
        uint256 high = entries.length;
        while (low < high) {
            uint256 mid = low + (high - low) / 2;
            if (ticketIndex < entries[mid].endIndex) {
                high = mid;
            } else {
                low = mid + 1;
            }
        }
        return entries[low].buyer;
    }
}
