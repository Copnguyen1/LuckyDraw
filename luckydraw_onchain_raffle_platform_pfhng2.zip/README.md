# LuckyDraw

An onchain USDC raffle platform on Arc Mainnet. Anyone can create a raffle, players buy tickets with USDC, and when time is up or every ticket is sold, anyone can trigger the draw. The contract picks a winner and pays out the pot in the same transaction.

Built with [Arc Studio](https://studio.arc.io)

## What you can do

- Explore live, ready-to-draw and finished raffles, with ticket progress, price and time remaining.
- Create a raffle by choosing a ticket price, a maximum number of tickets and a duration.
- Buy tickets with USDC. The app asks for an exact-amount USDC approval first, then the purchase.
- Draw a finished raffle with one button and watch the reveal animation (spinning wheel and cycling players, then a celebration).
- See your tickets, your created raffles, your wins and any unclaimed winnings under "My raffles".
- Browse every completed raffle and its winner under "Past winners".

## Raffle rules

- Ticket price: at least 0.01 USDC. Tickets per raffle: 2 to 1,000. Duration: 1 minute to 30 days.
- A raffle can be drawn once it has sold out or its end time has passed and at least one ticket was sold.
- A raffle that ends with no tickets can be closed by anyone, with nothing to pay out.
- The platform fee is 3% of the pot (the contract allows 2% to 5%). It is sent in the draw transaction to the contract's fixed fee wallet. The winner receives the rest.
- If the winner's address cannot receive USDC, the prize is held in the contract and can be claimed from "My raffles", so a draw can never get stuck.

## How randomness works

When the draw runs, the contract hashes the previous block hash together with the raffle id, the number of tickets sold and its own address. That number modulo the tickets sold picks the winning ticket, and the wallet holding that ticket is paid. A draw cannot happen in the same block as the last ticket purchase.

## Current limitations

Block-hash randomness is for demos only.

- Validators and block producers can influence block hashes.
- A ticket holder can simulate the draw offline and only submit it when they would win. Other players may draw first, but nothing forces them to.
- The contract has not had a third-party security audit.
- It runs on Arc Mainnet with real USDC. Only play with money you can afford to lose.

A production raffle should use verifiable randomness and lock ticket sales before requesting it.

## Tech stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS, framer-motion
- Wallet and chain access: wagmi v2, viem, ConnectKit (injected wallets)
- Contracts: Solidity 0.8.28, OpenZeppelin 5, Foundry
- Network: Arc Mainnet (chain ID 5042), RPC `https://rpc.mainnet.arc.io`, standard USDC at `0x3600000000000000000000000000000000000000`

## Deployment

| Item | Value |
| --- | --- |
| Network | Arc Mainnet (chain ID 5042) |
| LuckyDraw contract | `0x5CD290b15206cf9743CF91614Ef714D8b5C53721` |
| Explorer | https://explorer.arc.io/address/0x5CD290b15206cf9743CF91614Ef714D8b5C53721 |

## Development

Prerequisites: [Bun](https://bun.sh) and [Foundry](https://book.getfoundry.sh).

```bash
bun install
bun run dev
```

Environment variables (in `.env`):

- `VITE_LUCKYDRAW_ADDRESS`: address of the deployed LuckyDraw contract the app talks to.

Other commands:

```bash
bun run contracts:build   # compile contracts
bun run contracts:test    # run the Foundry test suite
bun run check             # lint and typecheck
```

Contract source is in `contracts/LuckyDraw.sol` and tests are in `contracts/test/`.
