import type { ReactNode } from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle, CheckCircle2, ExternalLink, Loader2, Sparkles, Trophy, Clock } from 'lucide-react'
import { useChainNow } from '@/hooks/useClock'
import { VIEW_LABEL, txUrl, type RaffleView } from '@/lib/contract'
import { formatDuration, shortAddr } from '@/lib/format'
import type { TxPhase } from '@/hooks/useContractTx'

export function ProgressBar({ value, tone = 'gold' }: { value: number; tone?: 'gold' | 'neon' }) {
  const color =
    tone === 'neon'
      ? 'linear-gradient(90deg,#1fe39a,#38ffb3)'
      : 'linear-gradient(90deg,#c98a12,#f8c84a 60%,#ffe08a)'
  return (
    <div
      className="h-2 w-full overflow-hidden rounded-full bg-white/[0.07]"
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full origin-left rounded-full transition-transform duration-700 ease-out"
        style={{ transform: `scaleX(${Math.max(0.015, value / 100)})`, background: color }}
      />
    </div>
  )
}

const BADGE: Record<RaffleView, string> = {
  active: 'border-neon-400/30 bg-neon-400/10 text-neon-400',
  ready: 'border-gold-400/50 bg-gold-400/15 text-gold-300',
  expired: 'border-white/10 bg-white/5 text-white/50',
  drawn: 'border-white/10 bg-white/5 text-white/70',
  cancelled: 'border-white/10 bg-white/5 text-white/50',
}

export function StatusBadge({ view }: { view: RaffleView }) {
  const Icon = view === 'ready' ? Sparkles : view === 'drawn' ? Trophy : view === 'active' ? null : Clock
  return (
    <span
      className={`inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-xs font-semibold ${BADGE[view]}`}
    >
      {view === 'active' ? (
        <span className="relative flex h-1.5 w-1.5">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-neon-400 opacity-70" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-neon-400" />
        </span>
      ) : Icon ? (
        <Icon size={12} />
      ) : null}
      {VIEW_LABEL[view]}
    </span>
  )
}

/** Compact countdown to a unix-seconds end time, driven by chain time. */
export function Countdown({ endTime, className = '' }: { endTime: number; className?: string }) {
  const now = useChainNow()
  const left = endTime - now
  if (left <= 0) return <span className={className}>Ended</span>
  const urgent = left < 300
  return (
    <span className={`num ${urgent ? 'text-gold-300' : ''} ${className}`}>{formatDuration(left)}</span>
  )
}

/** Large d/h/m/s countdown used on the detail page. */
export function BigCountdown({ endTime }: { endTime: number }) {
  const now = useChainNow()
  const left = Math.max(0, endTime - now)
  const parts = [
    { label: 'Days', value: Math.floor(left / 86400) },
    { label: 'Hours', value: Math.floor((left % 86400) / 3600) },
    { label: 'Min', value: Math.floor((left % 3600) / 60) },
    { label: 'Sec', value: left % 60 },
  ]
  return (
    <div className="grid grid-cols-4 gap-2 sm:gap-3" role="timer" aria-live="off">
      {parts.map((p) => (
        <div key={p.label} className="min-w-0 rounded-xl border border-white/[0.07] bg-ink-900/80 px-2 py-3 text-center">
          <div className="display num text-2xl font-bold leading-none text-white sm:text-3xl">
            {p.value.toString().padStart(2, '0')}
          </div>
          <div className="label mt-1.5 !text-[10px]">{p.label}</div>
        </div>
      ))}
    </div>
  )
}

export function Spinner({ size = 16 }: { size?: number }) {
  return <Loader2 size={size} className="animate-spin" aria-hidden="true" />
}

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} aria-hidden="true" />
}

export function EmptyState({
  icon,
  title,
  body,
  action,
}: {
  icon: ReactNode
  title: string
  body: string
  action?: ReactNode
}) {
  return (
    <div className="card flex flex-col items-center px-6 py-14 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-gold-400/25 bg-gold-400/10 text-gold-300">
        {icon}
      </div>
      <h3 className="display text-xl font-semibold text-white">{title}</h3>
      <p className="mt-1.5 max-w-sm text-sm text-white/55">{body}</p>
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  )
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="card flex flex-col items-center px-6 py-12 text-center">
      <AlertTriangle className="mb-3 text-rose-450" size={28} />
      <p className="text-sm text-white/70">{message}</p>
      {onRetry ? (
        <button className="btn-ghost btn-sm mt-4" onClick={onRetry}>
          Try again
        </button>
      ) : null}
    </div>
  )
}

export function PageHeading({ eyebrow, title, subtitle }: { eyebrow?: string; title: string; subtitle?: string }) {
  return (
    <div className="mb-7 animate-fade-up">
      {eyebrow ? <div className="label mb-2 !text-gold-400/80">{eyebrow}</div> : null}
      <h1 className="display text-3xl font-bold text-white sm:text-4xl">{title}</h1>
      {subtitle ? <p className="mt-2 max-w-xl text-[15px] text-white/55">{subtitle}</p> : null}
    </div>
  )
}

/** Honest transaction status: only reflects real wallet and chain states. */
export function TxNotice({
  phase,
  hash,
  error,
  walletText = 'Confirm in your wallet\u2026',
  confirmingText = 'Confirming on Arc Mainnet\u2026',
  successText = 'Confirmed on Arc Mainnet.',
}: {
  phase: TxPhase
  hash?: string
  error?: string
  walletText?: string
  confirmingText?: string
  successText?: string
}) {
  if (phase === 'idle') return null
  const link = hash ? (
    <a
      href={txUrl(hash)}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1 font-medium text-gold-300 underline-offset-2 hover:underline"
    >
      {shortAddr(hash)} <ExternalLink size={12} />
    </a>
  ) : null

  const tone =
    phase === 'error'
      ? 'border-rose-450/30 bg-rose-450/10 text-rose-450'
      : phase === 'success'
        ? 'border-neon-400/30 bg-neon-400/10 text-neon-400'
        : 'border-gold-400/25 bg-gold-400/[0.07] text-gold-300'

  return (
    <motion.div
      role="status"
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-sm ${tone}`}
    >
      <span className="mt-0.5">
        {phase === 'error' ? <AlertTriangle size={16} /> : phase === 'success' ? <CheckCircle2 size={16} /> : <Spinner />}
      </span>
      <div className="min-w-0 flex-1">
        <div className="font-medium">
          {phase === 'wallet' ? walletText : phase === 'confirming' ? confirmingText : phase === 'success' ? successText : error}
        </div>
        {link && phase !== 'wallet' ? <div className="mt-0.5 text-xs text-white/60">Tx {link}</div> : null}
      </div>
    </motion.div>
  )
}
