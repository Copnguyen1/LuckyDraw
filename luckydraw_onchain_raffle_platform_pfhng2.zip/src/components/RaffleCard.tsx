import { motion } from 'framer-motion'
import { ArrowUpRight, Ticket, Trophy } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { useChainNow } from '@/hooks/useClock'
import { deriveView, type Raffle } from '@/lib/contract'
import { pct, shortAddr, usdc, usdcSmart } from '@/lib/format'
import { Link } from '@/lib/router'
import { Countdown, ProgressBar, StatusBadge } from './ui'

export function RaffleCard({ raffle, index = 0 }: { raffle: Raffle; index?: number }) {
  const now = useChainNow()
  const view = deriveView(raffle, now)
  const pot = raffle.ticketPrice * BigInt(raffle.ticketsSold)
  const maxPot = raffle.ticketPrice * BigInt(raffle.maxTickets)
  const progress = pct(raffle.ticketsSold, raffle.maxTickets)
  const hot = view === 'ready'

  return (
    <motion.div
      className="min-w-0"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(index, 8) * 0.04 }}
    >
      <Link
        to={`/raffle/${raffle.id.toString()}`}
        className={`card card-hover group relative flex h-full flex-col overflow-hidden p-5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400/60 ${
          hot ? '!border-gold-400/45 shadow-gold' : ''
        }`}
      >
        {hot ? (
          <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-300 to-transparent" />
        ) : null}

        <div className="flex items-center justify-between gap-3">
          <span className="label whitespace-nowrap">Raffle #{raffle.id.toString()}</span>
          <StatusBadge view={view} />
        </div>

        <div className="mt-5">
          <div className="label">{view === 'drawn' ? 'Prize paid' : 'Current pot'}</div>
          <div className="mt-1.5 flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
            <span className="display num text-4xl font-bold leading-none text-white">
              {usdcSmart(view === 'drawn' ? raffle.payout : pot)}
            </span>
            <span className="inline-flex items-center gap-1 text-sm font-medium text-white/50">
              <TokenUSDC variant="branded" size={16} /> USDC
            </span>
          </div>
          {view !== 'drawn' ? (
            <div className="mt-2 text-xs text-white/40">Up to {usdc(maxPot)} USDC when sold out</div>
          ) : (
            <div className="mt-2 flex items-center gap-1.5 text-xs text-gold-300/90">
              <Trophy size={12} className="shrink-0" />
              <span className="whitespace-nowrap">Won by</span>
              <span className="mono-addr truncate">{shortAddr(raffle.winner)}</span>
            </div>
          )}
        </div>

        <div className="mt-5">
          <div className="mb-2 flex items-center justify-between gap-3 text-xs">
            <span className="num text-white/70">
              <span className="font-semibold text-white">{raffle.ticketsSold}</span> / {raffle.maxTickets} tickets
            </span>
            <span className="num shrink-0 text-white/45">{Math.round(progress)}%</span>
          </div>
          <ProgressBar value={progress} tone={view === 'active' ? 'gold' : 'neon'} />
        </div>

        <div className="mt-auto flex flex-wrap items-center justify-between gap-x-4 gap-y-2 border-t border-white/[0.06] pt-4 text-sm">
          <div className="inline-flex items-center gap-1.5 whitespace-nowrap text-white/60">
            <Ticket size={14} className="text-gold-400/80" />
            <span className="num font-medium text-white">{usdcSmart(raffle.ticketPrice)}</span> USDC
          </div>
          <div className="inline-flex items-center gap-2 whitespace-nowrap text-white/60">
            {view === 'active' ? (
              <>
                <span className="text-white/40">Ends in</span>
                <Countdown endTime={Number(raffle.endTime)} className="font-semibold text-white" />
              </>
            ) : view === 'ready' ? (
              <span className="font-semibold text-gold-300">Draw now</span>
            ) : (
              <span className="text-white/45">Finished</span>
            )}
            <ArrowUpRight size={16} className="text-white/30 transition group-hover:text-gold-300" />
          </div>
        </div>
      </Link>
    </motion.div>
  )
}

export function RaffleCardSkeleton() {
  return (
    <div className="card p-5">
      <div className="skeleton h-4 w-24" />
      <div className="skeleton mt-6 h-10 w-40" />
      <div className="skeleton mt-6 h-2 w-full" />
      <div className="skeleton mt-8 h-5 w-full" />
    </div>
  )
}
