import { useMemo, useState } from 'react'
import { erc20Abi } from 'viem'
import { useAccount, useReadContract, useWriteContract } from 'wagmi'
import { toast } from 'sonner'
import { Minus, Plus, ShieldCheck, Ticket } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { useContractTx } from '@/hooks/useContractTx'
import { useUsdc } from '@/hooks/useWallet'
import { LUCKYDRAW_ADDRESS, USDC_ADDRESS, luckyDraw, type Raffle } from '@/lib/contract'
import { usdc, usdcSmart } from '@/lib/format'
import { Spinner, TxNotice } from './ui'
import { WalletGate } from './WalletButton'

export function BuyPanel({ raffle, onBought }: { raffle: Raffle; onBought: () => void }) {
  const { address } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const { balance, allowance, refetch: refetchUsdc } = useUsdc()
  const approveTx = useContractTx()
  const buyTx = useContractTx()
  const [qtyInput, setQtyInput] = useState('1')

  const remaining = raffle.maxTickets - raffle.ticketsSold
  const qty = Number(qtyInput)
  const qtyValid = Number.isInteger(qty) && qty >= 1 && qty <= remaining
  const total = qtyValid ? raffle.ticketPrice * BigInt(qty) : 0n

  const myTicketsQ = useReadContract({
    ...luckyDraw,
    functionName: 'ticketsOf',
    args: address ? [raffle.id, address] : undefined,
    query: { enabled: !!address, refetchInterval: 8000 },
  })
  const myTickets = Number(myTicketsQ.data ?? 0)

  const insufficient = balance !== undefined && qtyValid && balance < total
  const needsApproval = qtyValid && allowance !== undefined && allowance < total
  const busy = approveTx.busy || buyTx.busy

  const odds = useMemo(() => {
    const denom = raffle.ticketsSold + (qtyValid ? qty : 0)
    if (denom === 0) return 0
    return ((myTickets + (qtyValid ? qty : 0)) / denom) * 100
  }, [raffle.ticketsSold, qty, qtyValid, myTickets])

  const setQty = (n: number) => setQtyInput(String(Math.max(1, Math.min(remaining, n))))

  const approve = async () => {
    buyTx.reset()
    const receipt = await approveTx.run(() =>
      writeContractAsync({
        address: USDC_ADDRESS,
        abi: erc20Abi,
        functionName: 'approve',
        args: [LUCKYDRAW_ADDRESS, total],
        chainId: luckyDraw.chainId,
      }),
    )
    if (receipt) {
      await refetchUsdc()
      toast.success('USDC approved. You can buy now.')
    }
  }

  const buy = async () => {
    approveTx.reset()
    const receipt = await buyTx.run(() =>
      writeContractAsync({ ...luckyDraw, functionName: 'buyTickets', args: [raffle.id, qty] }),
    )
    if (receipt) {
      toast.success(`${qty} ${qty === 1 ? 'ticket' : 'tickets'} purchased`)
      setQtyInput('1')
      await refetchUsdc()
      await myTicketsQ.refetch()
      onBought()
    }
  }

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between">
        <h3 className="display text-xl font-semibold text-white">Buy tickets</h3>
        <span className="num flex items-center gap-1.5 text-sm text-white/60">
          <TokenUSDC variant="branded" size={16} />
          <span className="font-semibold text-white">{usdcSmart(raffle.ticketPrice)}</span> each
        </span>
      </div>

      <div className="mt-5">
        <div className="mb-2 flex items-baseline justify-between">
          <span className="label">Quantity</span>
          <span className="num text-xs text-white/40">{remaining.toLocaleString()} left</span>
        </div>
        <div className="flex items-stretch gap-2">
          <button className="btn-ghost !px-3" onClick={() => setQty((qtyValid ? qty : 1) - 1)} disabled={busy} aria-label="Fewer tickets">
            <Minus size={16} />
          </button>
          <input
            className="input num text-center text-lg font-semibold"
            inputMode="numeric"
            value={qtyInput}
            onChange={(e) => setQtyInput(e.target.value.replace(/[^\d]/g, ''))}
            aria-invalid={!qtyValid}
            aria-label="Ticket quantity"
            disabled={busy}
          />
          <button className="btn-ghost !px-3" onClick={() => setQty((qtyValid ? qty : 0) + 1)} disabled={busy} aria-label="More tickets">
            <Plus size={16} />
          </button>
        </div>
        <div className="mt-2.5 flex flex-wrap gap-2">
          {[1, 5, 10].filter((n) => n < remaining).map((n) => (
            <button key={n} className="chip" data-active={qty === n} onClick={() => setQty(n)} disabled={busy}>
              {n}
            </button>
          ))}
          <button className="chip" data-active={qty === remaining} onClick={() => setQty(remaining)} disabled={busy}>
            All {remaining}
          </button>
        </div>
        {!qtyValid ? <p className="mt-2 text-xs text-rose-450">Choose between 1 and {remaining} tickets.</p> : null}
      </div>

      <dl className="mt-5 space-y-2.5 rounded-xl border border-white/[0.06] bg-ink-900/70 p-4 text-sm">
        <div className="flex justify-between">
          <dt className="text-white/55">Total</dt>
          <dd className="display num text-lg font-bold text-white">{usdc(total)} USDC</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-white/55">Your tickets after</dt>
          <dd className="num text-white/85">{(myTickets + (qtyValid ? qty : 0)).toLocaleString()}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-white/55">Your win chance</dt>
          <dd className="num text-neon-400">{odds.toFixed(odds >= 10 ? 1 : 2)}%</dd>
        </div>
      </dl>

      <div className="mt-5 space-y-3">
        <WalletGate prompt="Connect your wallet to buy tickets.">
          {insufficient ? (
            <div className="rounded-xl border border-rose-450/30 bg-rose-450/10 px-4 py-3 text-sm text-rose-450">
              You have {usdc(balance ?? 0n)} USDC but need {usdc(total)}. Add USDC to your wallet to continue.
            </div>
          ) : null}
          {needsApproval ? (
            <button className="btn-gold w-full" onClick={() => void approve()} disabled={busy || !qtyValid || insufficient}>
              {approveTx.busy ? <Spinner /> : <ShieldCheck size={16} />}
              {approveTx.phase === 'wallet' ? 'Confirm in wallet' : approveTx.phase === 'confirming' ? 'Approving' : `Allow ${usdc(total)} USDC`}
            </button>
          ) : (
            <button className="btn-gold w-full" onClick={() => void buy()} disabled={busy || !qtyValid || insufficient}>
              {buyTx.busy ? <Spinner /> : <Ticket size={16} />}
              {buyTx.phase === 'wallet'
                ? 'Confirm in wallet'
                : buyTx.phase === 'confirming'
                  ? 'Buying'
                  : `Buy ${qtyValid ? qty : ''} ${qty === 1 ? 'ticket' : 'tickets'}`}
            </button>
          )}
          {needsApproval ? (
            <p className="text-center text-xs text-white/40">Step 1 of 2: let the raffle contract take exactly {usdc(total)} USDC.</p>
          ) : null}
        </WalletGate>
        <TxNotice phase={approveTx.phase} hash={approveTx.hash} error={approveTx.error} successText="USDC approved." />
        <TxNotice phase={buyTx.phase} hash={buyTx.hash} error={buyTx.error} successText="Tickets purchased. Good luck!" />
      </div>
    </div>
  )
}
