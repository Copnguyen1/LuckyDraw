import { ConnectKitButton } from 'connectkit'
import { TokenUSDC } from '@web3icons/react'
import { Wallet } from 'lucide-react'
import { useUsdc, useWallet } from '@/hooks/useWallet'
import { CHAIN_NAME } from '@/lib/contract'
import { shortAddr, usdc } from '@/lib/format'
import { Spinner } from './ui'

export function UsdcBalanceChip() {
  const { isConnected, wrongChain } = useWallet()
  const { balance, isLoading } = useUsdc()
  if (!isConnected || wrongChain) return null
  return (
    <div
      className="hidden shrink-0 items-center gap-2 whitespace-nowrap rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-sm sm:flex"
      title="USDC balance (also used for network fees on Arc)"
    >
      <TokenUSDC variant="branded" size={18} />
      <span className="num font-semibold text-white">{isLoading || balance === undefined ? '\u2026' : usdc(balance)}</span>
      <span className="text-white/45">USDC</span>
    </div>
  )
}

export function WalletButton() {
  const { wrongChain, switchToArc, isSwitching } = useWallet()
  return (
    <ConnectKitButton.Custom>
      {({ isConnected, isConnecting, show, address }) => {
        if (!isConnected) {
          return (
            <button className="btn-gold btn-sm whitespace-nowrap sm:min-h-[44px] sm:px-5 sm:text-[15px]" onClick={show} disabled={isConnecting}>
              {isConnecting ? <Spinner /> : <Wallet size={16} />}
              {isConnecting ? 'Connecting' : (<>Connect<span className="hidden min-[400px]:inline">&nbsp;wallet</span></>)}
            </button>
          )
        }
        if (wrongChain) {
          return (
            <button className="btn-gold btn-sm whitespace-nowrap sm:min-h-[44px] sm:px-5 sm:text-[15px]" onClick={switchToArc} disabled={isSwitching}>
              {isSwitching ? <Spinner /> : null}
              <span className="min-[400px]:hidden">Wrong network</span>
              <span className="hidden min-[400px]:inline">Switch to {CHAIN_NAME}</span>
            </button>
          )
        }
        return (
          <button className="btn-ghost btn-sm whitespace-nowrap sm:min-h-[44px] sm:px-4 sm:text-[15px]" onClick={show}>
            <span className="h-2 w-2 rounded-full bg-neon-400 shadow-neon" />
            <span className="mono-addr">{address ? shortAddr(address) : ''}</span>
          </button>
        )
      }}
    </ConnectKitButton.Custom>
  )
}

/** Shown in place of an action when the wallet is not ready. Returns null when ready. */
export function WalletGate({ children, prompt = 'Connect your wallet to continue.' }: { children: React.ReactNode; prompt?: string }) {
  const { isConnected, wrongChain, switchToArc, isSwitching } = useWallet()
  if (isConnected && !wrongChain) return <>{children}</>
  return (
    <div className="rounded-xl border border-dashed border-white/15 bg-white/[0.02] p-4 text-center">
      <p className="mb-3 text-sm text-white/60">
        {wrongChain ? `Your wallet is on another network. Switch to ${CHAIN_NAME} to continue.` : prompt}
      </p>
      {wrongChain ? (
        <button className="btn-gold" onClick={switchToArc} disabled={isSwitching}>
          {isSwitching ? <Spinner /> : null}Switch to {CHAIN_NAME}
        </button>
      ) : (
        <ConnectKitButton.Custom>
          {({ show }) => (
            <button className="btn-gold" onClick={show}>
              <Wallet size={16} /> Connect wallet
            </button>
          )}
        </ConnectKitButton.Custom>
      )}
    </div>
  )
}
