import { ShieldAlert } from 'lucide-react'
import { Link } from '@/lib/router'

export function Disclaimer({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <p className="flex items-start gap-2 text-xs leading-relaxed text-white/45">
        <ShieldAlert size={14} className="mt-0.5 shrink-0 text-gold-400/80" />
        <span>
          Demo randomness: the winner is picked from a block hash, which block producers and well-timed callers can
          influence. This app uses real USDC on Arc Mainnet.{' '}
          <Link to="/fair" className="text-gold-300 underline-offset-2 hover:underline">
            How it works
          </Link>
        </span>
      </p>
    )
  }
  return (
    <div className="rounded-2xl border border-gold-400/25 bg-gold-400/[0.06] p-5">
      <div className="flex items-start gap-3">
        <ShieldAlert className="mt-0.5 shrink-0 text-gold-300" size={20} />
        <div>
          <h3 className="display text-base font-semibold text-gold-200">Randomness disclaimer</h3>
          <p className="mt-1.5 text-sm leading-relaxed text-white/70">
            LuckyDraw picks winners from the hash of a recent block. That is fine for a demo and unsafe for anything of
            real value: validators or block producers can influence block hashes, and a participant can choose when to
            submit the draw transaction. Raffles here use real USDC on Arc Mainnet, so only enter amounts you can afford to lose and
            treat outcomes as manipulable.
          </p>
        </div>
      </div>
    </div>
  )
}
