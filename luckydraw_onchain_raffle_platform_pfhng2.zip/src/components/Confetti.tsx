import { useEffect, useRef } from 'react'

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  size: number
  rot: number
  vr: number
  color: string
  shape: 'rect' | 'circle'
  life: number
}

const COLORS = ['#F8C84A', '#FFE08A', '#E9AD2B', '#38FFB3', '#FFFFFF', '#FFEDB3']

/** One-shot celebratory burst on a full-screen canvas. Skipped for reduced motion. */
export function Confetti({ run }: { run: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!run) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const resize = () => {
      canvas.width = window.innerWidth * dpr
      canvas.height = window.innerHeight * dpr
      canvas.style.width = `${window.innerWidth}px`
      canvas.style.height = `${window.innerHeight}px`
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener('resize', resize)

    const w = () => window.innerWidth
    const h = () => window.innerHeight
    const particles: Particle[] = []
    const burst = (cx: number, cy: number, count: number, spread: number, power: number) => {
      for (let i = 0; i < count; i++) {
        const angle = -Math.PI / 2 + (Math.random() - 0.5) * spread
        const speed = power * (0.45 + Math.random() * 0.75)
        particles.push({
          x: cx,
          y: cy,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          size: 5 + Math.random() * 7,
          rot: Math.random() * Math.PI,
          vr: (Math.random() - 0.5) * 0.35,
          color: COLORS[Math.floor(Math.random() * COLORS.length)],
          shape: Math.random() > 0.65 ? 'circle' : 'rect',
          life: 1,
        })
      }
    }

    burst(w() / 2, h() * 0.55, 150, Math.PI * 1.1, 17)
    const t1 = setTimeout(() => burst(w() * 0.2, h() * 0.8, 70, Math.PI / 2, 19), 250)
    const t2 = setTimeout(() => burst(w() * 0.8, h() * 0.8, 70, Math.PI / 2, 19), 450)

    let raf = 0
    const tick = () => {
      ctx.clearRect(0, 0, w(), h())
      let alive = 0
      for (const p of particles) {
        p.vy += 0.38
        p.vx *= 0.992
        p.x += p.vx
        p.y += p.vy
        p.rot += p.vr
        p.life -= 0.0045
        if (p.life <= 0 || p.y > h() + 40) continue
        alive++
        ctx.save()
        ctx.globalAlpha = Math.max(0, Math.min(1, p.life * 1.6))
        ctx.translate(p.x, p.y)
        ctx.rotate(p.rot)
        ctx.fillStyle = p.color
        if (p.shape === 'rect') ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2)
        else {
          ctx.beginPath()
          ctx.arc(0, 0, p.size / 3, 0, Math.PI * 2)
          ctx.fill()
        }
        ctx.restore()
      }
      if (alive > 0 || particles.length < 10) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)

    return () => {
      cancelAnimationFrame(raf)
      clearTimeout(t1)
      clearTimeout(t2)
      window.removeEventListener('resize', resize)
      ctx.clearRect(0, 0, w(), h())
    }
  }, [run])

  return <canvas ref={ref} className="pointer-events-none fixed inset-0 z-[70]" aria-hidden="true" />
}
