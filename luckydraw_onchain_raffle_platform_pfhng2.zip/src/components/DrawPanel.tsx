import { useState } from 'react'
import type { Address } from 'viem'
import { parseEventLogs } from 'viem'
import { useAccount, useWriteContract } from 'wagmi'
import { AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import { Dices, Lock } from 'lucide-react'
import { useContractTx } from '@/hooks/useContractTx'
import { luckyDrawAbi } from '@/lib/abi'
import { luckyDraw, type Raffle, type RaffleView } from '@/lib/contract'
import { Disclaimer } from './Disclaimer'
import { DrawStage, type DrawResult } from './DrawStage'
import { Spinner, TxNotice } from './ui'
import { WalletGate } from './WalletButton'

interface Props {
  raffle: Raffle
  view: RaffleView
  participants: Address[]
  onDone: () => void
  /** Tells the page to keep this panel mounted while the reveal is open, even after the raffle flips to drawn. */
  onSession: (active: boolean) => void
}

/** Prominent "Draw Now" call to action plus the draw animation. */
export function DrawPanel({ raffle, view, participants, onDone, onSession }: Props) {
  const { address } = useAccount()
  const { writeContractAsync } = useWriteContract()
  const tx = useContractTx()
  const [open, setOpen] = useState(false)
  const [result, setResult] = useState<DrawResult | undefined>()
  const [snapshot, setSnapshot] = useState<Address[]>([])

  const emptyRaffle = view === 'expired'

  const showCard = view === 'ready' || view === 'expired'

  const start = async () => {
    setSnapshot(participants)
    setResult(undefined)
    setOpen(!emptyRaffle)
    onSession(!emptyRaffle)
    const receipt = await tx.run(
      () => writeContractAsync({ ...luckyDraw, functionName: 'drawRaffle', args: [raffle.id] }),
      () => {
        // Wallet signature declined: close the reveal.
        setOpen(false)
        onSession(false)
      },
    )
    if (!receipt) return
    const drawn = parseEventLogs({ abi: luckyDrawAbi, eventName: 'RaffleDrawn', logs: receipt.logs })[0]
    if (drawn) {
      setResult({
        winner: drawn.args.winner,
        winningTicket: drawn.args.winningTicket,
        ticketsSold: raffle.ticketsSold,
        payout: drawn.args.payout,
      })
    } else {
      toast.success('Raffle closed. No tickets were sold, so nothing to pay out.')
    }
    onDone()
  }

  const closeStage = () => {
    setOpen(false)
    onSession(false)
    tx.reset()
    onDone()
  }

  return (
    <>
      {showCard ? (
      <div className="card relative overflow-hidden border-gold-400/30 p-6 shadow-gold">
        <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-gold-400/15 blur-3xl" />
        <div className="relative">
          <div className="label !text-gold-400/90">{emptyRaffle ? 'Ended with no tickets' : 'Ready to draw'}</div>
          <h3 className="display mt-1 text-2xl font-bold text-white">
            {emptyRaffle ? 'Close this raffle' : raffle.ticketsSold >= raffle.maxTickets ? 'Sold out. Pick the winner.' : 'Time is up. Pick the winner.'}
          </h3>
          <p className="mt-2 text-sm text-white/60">
            {emptyRaffle
              ? 'Nobody bought a ticket. Anyone can close it to mark it finished.'
              : 'Anyone can trigger the draw. The contract picks a winner and pays the pot out in the same transaction.'}
          </p>

          <div className="mt-5">
            <WalletGate prompt="Connect your wallet to trigger the draw.">
              <div className="relative">
                {!tx.busy && !emptyRaffle ? <span className="absolute inset-0 animate-pulse-ring rounded-xl" aria-hidden="true" /> : null}
                <button className="btn-gold relative w-full !min-h-[56px] text-lg" onClick={() => void start()} disabled={tx.busy || !address}>
                  {tx.busy ? <Spinner size={18} /> : emptyRaffle ? <Lock size={18} /> : <Dices size={20} />}
                  {tx.phase === 'wallet' ? 'Confirm in wallet' : tx.phase === 'confirming' ? 'Drawing' : emptyRaffle ? 'Close raffle' : 'Draw now'}
                </button>
              </div>
            </WalletGate>
          </div>
          {!open ? (
            <div className="mt-4">
              <TxNotice
                phase={tx.phase}
                hash={tx.hash}
                error={tx.error}
                successText={emptyRaffle ? 'Raffle closed.' : 'Draw confirmed.'}
              />
            </div>
          ) : null}
        </div>
      </div>
      ) : null}
      {showCard ? <Disclaimer compact /> : null}

      <AnimatePresence>
        {open ? (
          <DrawStage
            key="stage"
            raffleId={raffle.id}
            mode="live"
            participants={snapshot}
            me={address}
            phase={tx.phase}
            hash={tx.hash}
            error={tx.error}
            result={result}
            onClose={closeStage}
          />
        ) : null}
      </AnimatePresence>
    </>
  )
}
