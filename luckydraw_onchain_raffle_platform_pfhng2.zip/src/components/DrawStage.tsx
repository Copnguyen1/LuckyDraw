import { useEffect, useMemo, useRef, useState } from 'react'
import type { Address, Hash } from 'viem'
import { AnimatePresence, motion } from 'framer-motion'
import { AlertTriangle, ExternalLink, PartyPopper, Trophy, X } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import type { TxPhase } from '@/hooks/useContractTx'
import { CHAIN_NAME, addressUrl, txUrl } from '@/lib/contract'
import { shortAddr, usdc } from '@/lib/format'
import { Confetti } from './Confetti'
import { Spinner } from './ui'

export interface DrawResult {
  winner: Address
  winningTicket: number
  ticketsSold: number
  payout: bigint
}

type Stage = 'waiting' | 'spinning' | 'landing' | 'revealed'

const MIN_SPIN_MS = 2400
const LANDING_DELAYS = [110, 140, 180, 240, 320, 430, 580, 760]

interface Props {
  raffleId: bigint
  mode: 'live' | 'replay'
  participants: Address[]
  me?: Address
  phase?: TxPhase
  hash?: Hash
  error?: string
  result?: DrawResult
  onClose: () => void
}

export function DrawStage({ raffleId, mode, participants, me, phase = 'success', hash, error, result, onClose }: Props) {
  // The reel only moves forward from spinning, so 'landing' and 'revealed' are stored; the earlier stages derive from props.
  const [later, setLater] = useState<'landing' | 'revealed' | null>(null)
  const [shown, setShown] = useState<Address | undefined>()
  const spinStart = useRef<number>(0)
  const stage: Stage = later ?? (mode === 'replay' || hash ? 'spinning' : 'waiting')

  const poolKey = useMemo(() => {
    const set = new Set<Address>(participants)
    if (result) set.add(result.winner)
    return Array.from(set).join(',')
  }, [participants, result])
  const pool = useMemo(() => (poolKey ? (poolKey.split(',') as Address[]) : []), [poolKey])

  // Effects below key off the primitive result identity, not the object, so parent re-renders never restart the reel.
  const resultRef = useRef(result)
  useEffect(() => {
    resultRef.current = result
  })
  const resultKey = result ? `${result.winner}:${result.winningTicket}` : ''
  const hasResult = resultKey !== ''

  const failed = phase === 'error'

  // Fast cycling while the draw is in flight; lands once the result is known.
  useEffect(() => {
    if (stage !== 'spinning' || pool.length === 0) return
    if (spinStart.current === 0) spinStart.current = Date.now()
    const id = setInterval(() => {
      setShown(pool[Math.floor(Math.random() * pool.length)])
      if (hasResult && Date.now() - spinStart.current >= MIN_SPIN_MS) {
        clearInterval(id)
        setLater('landing')
      }
    }, 75)
    return () => clearInterval(id)
  }, [stage, pool, hasResult])

  // Decelerating reel that ends exactly on the winner.
  useEffect(() => {
    const finalResult = resultRef.current
    if (stage !== 'landing' || !finalResult) return
    let cancelled = false
    let timer: ReturnType<typeof setTimeout> | undefined
    let i = 0
    const step = () => {
      if (cancelled) return
      if (i >= LANDING_DELAYS.length) {
        setLater('revealed')
        return
      }
      const last = i === LANDING_DELAYS.length - 1
      setShown((prev) => {
        if (last) return finalResult.winner
        const others = pool.filter((a) => a !== prev)
        const choices = others.length > 0 ? others : pool
        return choices[Math.floor(Math.random() * choices.length)]
      })
      timer = setTimeout(step, LANDING_DELAYS[i])
      i += 1
    }
    timer = setTimeout(step, 0)
    return () => {
      cancelled = true
      if (timer) clearTimeout(timer)
    }
  }, [stage, resultKey, pool])

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const iWon = !!me && !!result && me.toLowerCase() === result.winner.toLowerCase()
  const revealed = stage === 'revealed' && !!result
  const spinning = stage === 'spinning'

  const heading = failed
    ? 'The draw did not go through'
    : stage === 'waiting'
      ? 'Ready when you are'
      : revealed
        ? iWon
          ? 'You won!'
          : 'We have a winner'
        : stage === 'landing'
          ? 'Almost there\u2026'
          : 'Drawing the winner\u2026'

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex items-center justify-center overflow-y-auto bg-ink-950/90 p-4 backdrop-blur-md"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      role="dialog"
      aria-modal="true"
      aria-label={`Draw for raffle ${raffleId.toString()}`}
    >
      <Confetti run={revealed} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(600px_400px_at_50%_40%,rgba(248,200,74,0.14),transparent_70%)]" />

      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: 'spring', stiffness: 300, damping: 26 }}
        className="card relative my-auto w-full max-w-md overflow-hidden px-6 pb-7 pt-8 text-center"
      >
        <button className="absolute right-3 top-3 rounded-lg p-2 text-white/50 hover:bg-white/10 hover:text-white" onClick={onClose} aria-label="Close">
          <X size={18} />
        </button>

        <div className="label !text-gold-400/90">Raffle #{raffleId.toString()}</div>
        <h2 className="display mt-1 text-3xl font-bold text-white">
          {revealed && iWon ? <span className="gold-text">{heading}</span> : heading}
        </h2>

        <div className="relative mx-auto mt-7 h-60 w-60">
          <div
            className={`wheel-ring absolute inset-0 rounded-full ${
              spinning ? 'animate-spin-fast' : stage === 'landing' ? 'animate-spin-slow' : ''
            } ${revealed ? 'opacity-90' : 'opacity-100'}`}
            style={{ filter: revealed ? 'drop-shadow(0 0 18px rgba(248,200,74,0.7))' : 'drop-shadow(0 0 10px rgba(248,200,74,0.35))' }}
          />
          <div className="absolute inset-[14px] flex flex-col items-center justify-center rounded-full border border-white/[0.08] bg-ink-900 px-4 shadow-[inset_0_0_40px_rgba(0,0,0,0.6)]">
            {failed ? (
              <AlertTriangle className="text-rose-450" size={36} />
            ) : stage === 'waiting' ? (
              <>
                <Spinner size={28} />
                <p className="mt-3 text-sm text-white/60">Confirm the draw in your wallet</p>
              </>
            ) : revealed && result ? (
              <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 14 }}>
                <Trophy className="mx-auto text-gold-300 drop-shadow-[0_0_14px_rgba(248,200,74,0.8)]" size={40} />
                <div className="mono-addr mt-2 text-lg font-semibold text-white">{shortAddr(result.winner)}</div>
                <div className="mt-0.5 text-xs text-white/50">
                  Ticket #{result.winningTicket + 1} of {result.ticketsSold}
                </div>
              </motion.div>
            ) : (
              <>
                <div className="label mb-2 !text-[10px]">{pool.length} {pool.length === 1 ? 'player' : 'players'} in the draw</div>
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.div
                    key={shown ?? 'none'}
                    initial={{ y: -14, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 14, opacity: 0 }}
                    transition={{ duration: 0.07 }}
                    className={`mono-addr text-xl font-semibold ${spinning ? 'text-white/85 blur-[0.6px]' : 'text-gold-300'}`}
                  >
                    {shown ? shortAddr(shown) : '\u2026'}
                  </motion.div>
                </AnimatePresence>
              </>
            )}
          </div>
        </div>

        <div className="mt-6 min-h-[88px]">
          {failed ? (
            <p className="text-sm text-rose-450">{error ?? 'The transaction failed. Close this and try again.'}</p>
          ) : revealed && result ? (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
              <div className="flex items-center justify-center gap-2 text-sm text-white/60">
                {iWon ? <PartyPopper size={16} className="text-neon-400" /> : null}
                {iWon ? 'Your prize was sent to your wallet' : 'Prize sent to the winner'}
              </div>
              <div className="display num mt-1 flex items-center justify-center gap-2 text-3xl font-bold text-neon-400">
                +{usdc(result.payout)} <TokenUSDC variant="branded" size={22} />
              </div>
              <a
                href={addressUrl(result.winner)}
                target="_blank"
                rel="noopener noreferrer"
                className="mono-addr mt-2 inline-flex max-w-full items-center gap-1 break-all text-xs text-white/45 hover:text-gold-300"
              >
                {result.winner} <ExternalLink size={11} className="shrink-0" />
              </a>
            </motion.div>
          ) : (
            <p className="text-sm text-white/50">
              {stage === 'waiting'
                ? 'Approve the transaction to start the draw.'
                : `Waiting for ${CHAIN_NAME} to confirm the draw\u2026`}
            </p>
          )}
        </div>

        <div className="mt-2 flex flex-col items-center gap-3">
          {hash ? (
            <a
              href={txUrl(hash)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-white/50 hover:text-gold-300"
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${phase === 'success' ? 'bg-neon-400' : failed ? 'bg-rose-450' : 'animate-pulse bg-gold-400'}`}
              />
              {phase === 'success' ? 'Confirmed' : failed ? 'Failed' : 'Confirming'}{' \u00b7 '}<span className="mono-addr">{shortAddr(hash)}</span>
              <ExternalLink size={11} />
            </a>
          ) : null}
          {(revealed || failed) && (
            <button className="btn-gold min-w-[180px]" onClick={onClose}>
              {failed ? 'Close' : 'See results'}
            </button>
          )}
          {mode === 'live' && !revealed && !failed ? (
            <p className="text-[11px] text-white/35">The winner is already decided onchain. This is just the reveal.</p>
          ) : null}
        </div>
      </motion.div>
    </motion.div>
  )
}
