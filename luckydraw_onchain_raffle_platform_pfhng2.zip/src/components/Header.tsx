import { Link } from '@/lib/router'
import type { Route } from '@/lib/router'
import { Logo } from './Logo'
import { UsdcBalanceChip, WalletButton } from './WalletButton'

const NAV: { to: string; label: string; match: Route['name'][] }[] = [
  { to: '/', label: 'Explore', match: ['home', 'raffle'] },
  { to: '/create', label: 'Create', match: ['create'] },
  { to: '/mine', label: 'My Raffles', match: ['mine'] },
  { to: '/winners', label: 'Past Winners', match: ['winners'] },
  { to: '/fair', label: 'Fair Play', match: ['fair'] },
]

function NavLinks({ route, variant }: { route: Route; variant: 'desktop' | 'mobile' }) {
  return (
    <>
      {NAV.map((item) => {
        const active = item.match.includes(route.name)
        const base = 'shrink-0 whitespace-nowrap font-medium transition-colors'
        const size = variant === 'desktop' ? 'rounded-lg px-3 py-2 text-sm' : 'rounded-full px-4 py-2 text-sm'
        const tone = active
          ? variant === 'desktop'
            ? 'bg-white/[0.08] text-gold-300'
            : 'bg-gold-400/15 text-gold-300'
          : 'text-white/65 hover:bg-white/[0.05] hover:text-white'
        return (
          <Link key={item.to} to={item.to} aria-current={active ? 'page' : undefined} className={`${base} ${size} ${tone}`}>
            {item.label}
          </Link>
        )
      })}
    </>
  )
}

export function Header({ route }: { route: Route }) {
  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ink-950/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-3 px-4 sm:gap-4 sm:px-6">
        <Link
          to="/"
          className="shrink-0 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold-400/60"
          aria-label="LuckyDraw home"
        >
          <Logo />
        </Link>

        <nav className="ml-6 hidden items-center gap-1 lg:flex" aria-label="Main">
          <NavLinks route={route} variant="desktop" />
        </nav>

        <div className="ml-auto flex shrink-0 items-center gap-2">
          <UsdcBalanceChip />
          <WalletButton />
        </div>
      </div>

      <nav
        className="no-scrollbar flex gap-2 overflow-x-auto border-t border-white/[0.05] px-4 py-2.5 sm:px-6 lg:hidden"
        aria-label="Main mobile"
      >
        <NavLinks route={route} variant="mobile" />
      </nav>
    </header>
  )
}
