import { useId } from 'react'

export function LogoMark({ size = 32 }: { size?: number }) {
  const gid = useId()
  return (
    <svg width={size} height={(size * 28) / 40} viewBox="0 0 40 28" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="40" y2="28" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FFEDB3" />
          <stop offset="0.5" stopColor="#F8C84A" />
          <stop offset="1" stopColor="#E9AD2B" />
        </linearGradient>
      </defs>
      <path
        d="M4 0H36a4 4 0 0 1 4 4V9a5 5 0 0 0 0 10V24a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V19a5 5 0 0 0 0-10V4a4 4 0 0 1 4-4Z"
        fill={`url(#${gid})`}
      />
      <path d="M20 5.5l2.3 6.2L28.5 14l-6.2 2.3L20 22.5l-2.3-6.2L11.5 14l6.2-2.3Z" fill="#06060b" />
      <path d="M31 6.5v2M30 7.5h2M9 19.5v2M8 20.5h2" stroke="#06060b" strokeWidth="1.1" strokeLinecap="round" opacity="0.55" />
    </svg>
  )
}

export function Logo({ size = 32 }: { size?: number }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <LogoMark size={size} />
      <span className="display text-[21px] font-bold leading-none tracking-tight text-white">
        Lucky<span className="gold-text">Draw</span>
      </span>
    </span>
  )
}
