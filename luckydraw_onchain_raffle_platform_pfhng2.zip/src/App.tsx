import { AnimatePresence, motion } from 'framer-motion'
import { Header } from '@/components/Header'
import { Logo } from '@/components/Logo'
import { EmptyState } from '@/components/ui'
import { ClockProvider } from '@/hooks/useClock'
import { LUCKYDRAW_ADDRESS, CHAIN_ID, CHAIN_NAME, addressUrl } from '@/lib/contract'
import { Link, useRoute } from '@/lib/router'
import { Create } from '@/pages/Create'
import { Explore } from '@/pages/Explore'
import { Fair } from '@/pages/Fair'
import { MyRaffles } from '@/pages/MyRaffles'
import { RaffleDetail } from '@/pages/RaffleDetail'
import { Winners } from '@/pages/Winners'
import { Compass, TriangleAlert } from 'lucide-react'
import { useBytecode } from 'wagmi'

function Footer() {
  return (
    <footer className="mt-16 border-t border-white/[0.06] pb-24 pt-8">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-4 text-sm text-white/45 sm:flex-row sm:items-center sm:px-6">
        <Logo size={26} />
        <p className="max-w-md text-xs leading-relaxed">
          Runs on {CHAIN_NAME} with real USDC. Winners are picked from block hashes, which can be influenced.
          Only play with money you can afford to lose.
        </p>
        <a href={addressUrl(LUCKYDRAW_ADDRESS)} target="_blank" rel="noopener noreferrer" className="text-xs hover:text-gold-300">
          View contract
        </a>
      </div>
    </footer>
  )
}

function ContractMissingBanner() {
  const { data, isSuccess } = useBytecode({ address: LUCKYDRAW_ADDRESS, chainId: CHAIN_ID })
  if (!isSuccess || (data && data !== '0x')) return null
  return (
    <div role="alert" className="border-b border-rose-450/30 bg-rose-450/10">
      <div className="mx-auto flex max-w-6xl items-start gap-3 px-4 py-3 text-sm text-rose-450 sm:px-6">
        <TriangleAlert size={18} className="mt-0.5 shrink-0" />
        <p>
          No LuckyDraw contract was found at{' '}
          <a href={addressUrl(LUCKYDRAW_ADDRESS)} target="_blank" rel="noopener noreferrer" className="mono-addr break-all underline">
            {LUCKYDRAW_ADDRESS}
          </a>{' '}
          on {CHAIN_NAME}. Raffles cannot load or be created until the contract is deployed there.
        </p>
      </div>
    </div>
  )
}

export default function App() {
  const route = useRoute()
  const key = route.name === 'raffle' ? `raffle-${route.id.toString()}` : route.name

  return (
    <ClockProvider>
      <div className="flex min-h-dvh flex-col">
        <Header route={route} />
        <ContractMissingBanner />
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6 sm:py-10">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={key}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
            >
              {route.name === 'home' && <Explore />}
              {route.name === 'create' && <Create />}
              {route.name === 'raffle' && <RaffleDetail id={route.id} />}
              {route.name === 'mine' && <MyRaffles />}
              {route.name === 'winners' && <Winners />}
              {route.name === 'fair' && <Fair />}
              {route.name === 'notfound' && (
                <EmptyState
                  icon={<Compass size={26} />}
                  title="Page not found"
                  body="That page does not exist. Head back to the raffles."
                  action={
                    <Link to="/" className="btn-gold">
                      Explore raffles
                    </Link>
                  }
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
        <Footer />
      </div>
    </ClockProvider>
  )
}
