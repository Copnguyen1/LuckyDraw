import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { useBlock } from 'wagmi'
import { CHAIN_ID } from '@/lib/contract'

const ClockContext = createContext<number>(Math.floor(Date.now() / 1000))

const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v))

/**
 * Provides "now" in unix seconds, corrected towards the latest block timestamp.
 * The contract compares against block.timestamp, so countdowns follow chain time
 * (the correction is clamped so an idle chain can't drag the clock far off).
 */
export function ClockProvider({ children }: { children: ReactNode }) {
  const { data: block, dataUpdatedAt } = useBlock({ chainId: CHAIN_ID, query: { refetchInterval: 15_000 } })
  const [tick, setTick] = useState(() => Date.now())

  useEffect(() => {
    const id = setInterval(() => setTick(Date.now()), 1000)
    return () => clearInterval(id)
  }, [])

  const offset = useMemo(() => {
    if (!block) return 0
    return clamp(Number(block.timestamp) - Math.floor(dataUpdatedAt / 1000), -120, 120)
  }, [block, dataUpdatedAt])

  return <ClockContext.Provider value={Math.floor(tick / 1000) + offset}>{children}</ClockContext.Provider>
}

export function useChainNow(): number {
  return useContext(ClockContext)
}
