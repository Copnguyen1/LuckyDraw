import { erc20Abi } from 'viem'
import { useAccount, useReadContract, useSwitchChain } from 'wagmi'
import { CHAIN_ID, LUCKYDRAW_ADDRESS, USDC_ADDRESS } from '@/lib/contract'

/** Connected account plus whether the wallet sits on Arc Mainnet. */
export function useWallet() {
  const { address, isConnected, isConnecting, chainId } = useAccount()
  const { switchChain, isPending: isSwitching } = useSwitchChain()
  const wrongChain = isConnected && chainId !== CHAIN_ID
  return {
    address,
    isConnected,
    isConnecting,
    wrongChain,
    isSwitching,
    switchToArc: () => switchChain({ chainId: CHAIN_ID }),
  }
}

/** USDC (ERC-20 view, 6 decimals) balance and allowance towards the LuckyDraw contract. */
export function useUsdc() {
  const { address } = useAccount()

  const balanceQ = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address, refetchInterval: 10_000 },
  })

  const allowanceQ = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address ? [address, LUCKYDRAW_ADDRESS] : undefined,
    chainId: CHAIN_ID,
    query: { enabled: !!address, refetchInterval: 10_000 },
  })

  return {
    balance: balanceQ.data,
    allowance: allowanceQ.data,
    isLoading: balanceQ.isLoading,
    refetch: async () => {
      await Promise.all([balanceQ.refetch(), allowanceQ.refetch()])
    },
  }
}
