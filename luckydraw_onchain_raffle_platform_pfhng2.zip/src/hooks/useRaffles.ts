import { useMemo } from 'react'
import type { Address } from 'viem'
import { useReadContract, useReadContracts } from 'wagmi'
import { luckyDraw, type Raffle } from '@/lib/contract'

const WINDOW = 100n
const POLL = 8_000

/** The latest raffles (newest first), polled from the contract. */
export function useRaffles() {
  const countQ = useReadContract({ ...luckyDraw, functionName: 'raffleCount', query: { refetchInterval: POLL } })
  const count = countQ.data ?? 0n
  const from = count > WINDOW ? count - WINDOW + 1n : 1n

  const listQ = useReadContract({
    ...luckyDraw,
    functionName: 'getRaffles',
    args: [from, count > 0n ? count - from + 1n : 0n],
    query: { enabled: countQ.isSuccess && count > 0n, refetchInterval: POLL },
  })

  const raffles = useMemo<Raffle[]>(() => {
    const data = listQ.data
    if (!data) return []
    return data.map((r, i) => ({ ...r, id: from + BigInt(i) })).reverse()
  }, [listQ.data, from])

  return {
    raffles,
    count,
    isLoading: countQ.isLoading || (count > 0n && listQ.isLoading),
    isError: countQ.isError || listQ.isError,
    refetch: async () => {
      await countQ.refetch()
      await listQ.refetch()
    },
  }
}

export function useRaffle(id: bigint) {
  const q = useReadContract({
    ...luckyDraw,
    functionName: 'getRaffle',
    args: [id],
    query: { refetchInterval: 5_000 },
  })
  const raffle = useMemo<Raffle | undefined>(() => {
    const data = q.data
    return data ? { ...data, id } : undefined
  }, [q.data, id])
  return { raffle, isLoading: q.isLoading, isError: q.isError, refetch: q.refetch }
}

export interface Participant {
  address: Address
  tickets: number
}

export function useParticipants(id: bigint, ticketsSold: number) {
  const listQ = useReadContract({
    ...luckyDraw,
    functionName: 'getParticipants',
    args: [id],
    query: { refetchInterval: 10_000 },
    scopeKey: `participants-${ticketsSold}`,
  })
  const addrs = useMemo(() => (listQ.data ? [...listQ.data] : []), [listQ.data])

  const countsQ = useReadContracts({
    contracts: addrs.slice(0, 200).map((a) => ({ ...luckyDraw, functionName: 'ticketsOf' as const, args: [id, a] as const })),
    query: { enabled: addrs.length > 0 },
  })

  const participants = useMemo<Participant[]>(() => {
    return addrs.map((address, i) => {
      const res = countsQ.data?.[i]
      const tickets = res && res.status === 'success' ? Number(res.result) : 0
      return { address, tickets }
    })
  }, [addrs, countsQ.data])

  return { participants, isLoading: listQ.isLoading, refetch: listQ.refetch }
}

export interface MyTicketRow {
  raffle: Raffle
  tickets: number
}

/** Raffles the wallet created and joined, plus its ticket counts. */
export function useMyRaffles(address: Address | undefined) {
  const idsQ = useReadContract({
    ...luckyDraw,
    functionName: 'getUserRaffles',
    args: address ? [address] : undefined,
    query: { enabled: !!address, refetchInterval: POLL },
  })

  const created = useMemo(() => (idsQ.data ? [...idsQ.data[0]] : []), [idsQ.data])
  const joined = useMemo(() => (idsQ.data ? [...idsQ.data[1]] : []), [idsQ.data])
  const allIds = useMemo(() => Array.from(new Set([...created, ...joined])), [created, joined])

  const rafflesQ = useReadContracts({
    contracts: allIds.map((id) => ({ ...luckyDraw, functionName: 'getRaffle' as const, args: [id] as const })),
    query: { enabled: allIds.length > 0, refetchInterval: POLL },
  })
  const ticketsQ = useReadContracts({
    contracts: joined.map((id) => ({
      ...luckyDraw,
      functionName: 'ticketsOf' as const,
      args: [id, address ?? '0x0000000000000000000000000000000000000000'] as const,
    })),
    query: { enabled: !!address && joined.length > 0, refetchInterval: POLL },
  })

  const byId = useMemo(() => {
    const map = new Map<string, Raffle>()
    allIds.forEach((id, i) => {
      const res = rafflesQ.data?.[i]
      if (res && res.status === 'success') map.set(id.toString(), { ...(res.result), id })
    })
    return map
  }, [allIds, rafflesQ.data])

  const createdRaffles = useMemo(
    () => created.map((id) => byId.get(id.toString())).filter((r): r is Raffle => !!r).reverse(),
    [created, byId],
  )

  const tickets = useMemo<MyTicketRow[]>(() => {
    const rows: MyTicketRow[] = []
    joined.forEach((id, i) => {
      const raffle = byId.get(id.toString())
      const res = ticketsQ.data?.[i]
      if (raffle && res && res.status === 'success') rows.push({ raffle, tickets: Number(res.result) })
    })
    return rows.reverse()
  }, [joined, byId, ticketsQ.data])

  const loading =
    !!address && (idsQ.isLoading || (allIds.length > 0 && rafflesQ.isLoading) || (joined.length > 0 && ticketsQ.isLoading))

  return { created: createdRaffles, tickets, isLoading: loading, isError: idsQ.isError }
}

export function useClaimable(address: Address | undefined) {
  const q = useReadContract({
    ...luckyDraw,
    functionName: 'claimable',
    args: address ? [address] : undefined,
    query: { enabled: !!address, refetchInterval: 10_000 },
  })
  return { amount: q.data ?? 0n, refetch: q.refetch }
}

export function useFeeBps() {
  const q = useReadContract({ ...luckyDraw, functionName: 'feeBps', query: { staleTime: 60_000 } })
  return q.data ?? 300
}
