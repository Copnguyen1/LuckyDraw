import { useCallback, useState } from 'react'
import type { Hash, TransactionReceipt } from 'viem'
import { usePublicClient } from 'wagmi'
import { CHAIN_ID } from '@/lib/contract'
import { parseTxError } from '@/lib/errors'

export type TxPhase = 'idle' | 'wallet' | 'confirming' | 'success' | 'error'

/**
 * Tracks one write transaction through real states:
 * wallet signature, chain confirmation, success or error.
 */
export function useContractTx() {
  const client = usePublicClient({ chainId: CHAIN_ID })
  const [phase, setPhase] = useState<TxPhase>('idle')
  const [hash, setHash] = useState<Hash | undefined>()
  const [receipt, setReceipt] = useState<TransactionReceipt | undefined>()
  const [error, setError] = useState<string | undefined>()

  const reset = useCallback(() => {
    setPhase('idle')
    setHash(undefined)
    setReceipt(undefined)
    setError(undefined)
  }, [])

  /**
   * `send` must submit the transaction and resolve with its hash. Resolves with the receipt, or null on failure.
   * `onRejected` fires when the wallet signature was declined.
   */
  const run = useCallback(
    async (send: () => Promise<Hash>, onRejected?: () => void): Promise<TransactionReceipt | null> => {
      setPhase('wallet')
      setError(undefined)
      setHash(undefined)
      setReceipt(undefined)
      try {
        const h = await send()
        setHash(h)
        setPhase('confirming')
        if (!client) throw new Error('network: no public client')
        const r = await client.waitForTransactionReceipt({ hash: h })
        if (r.status !== 'success') throw new Error('reverted')
        setReceipt(r)
        setPhase('success')
        return r
      } catch (e) {
        const parsed = parseTxError(e)
        if (parsed.rejected) {
          setPhase('idle')
          onRejected?.()
        } else {
          setError(parsed.message)
          setPhase('error')
        }
        return null
      }
    },
    [client],
  )

  return { phase, hash, receipt, error, run, reset, busy: phase === 'wallet' || phase === 'confirming' }
}
