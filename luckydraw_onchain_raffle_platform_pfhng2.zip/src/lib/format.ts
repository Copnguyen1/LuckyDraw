import { Amount } from '@/onchain-money'
import { USDC_DECIMALS } from './contract'

export const shortAddr = (addr: string) => `${addr.slice(0, 6)}\u2026${addr.slice(-4)}`

/** "12.50" style USDC (ERC-20 view, 6 decimals), grouped with thousands separators. */
export function usdc(raw: bigint, fractionDigits = 2): string {
  const fixed = Amount.fromRaw(raw, USDC_DECIMALS).toFixed(fractionDigits)
  const [whole, frac] = fixed.split('.')
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  return frac ? `${grouped}.${frac}` : grouped
}

/** Drops trailing zero decimals beyond two ("1.5" -> "1.50", "0.015" -> "0.015"). */
export function usdcSmart(raw: bigint): string {
  const exact = Amount.fromRaw(raw, USDC_DECIMALS).toString()
  const [, frac = ''] = exact.split('.')
  return usdc(raw, Math.min(6, Math.max(2, frac.length)))
}

export function formatDuration(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds))
  const d = Math.floor(s / 86400)
  const h = Math.floor((s % 86400) / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  if (d > 0) return `${d}d ${h}h`
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${sec.toString().padStart(2, '0')}s`
  return `${sec}s`
}

export function formatDate(unixSeconds: number | bigint): string {
  return new Date(Number(unixSeconds) * 1000).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function pct(part: number, whole: number): number {
  if (whole <= 0) return 0
  return Math.min(100, Math.max(0, (part / whole) * 100))
}
