import { useEffect, useSyncExternalStore, type AnchorHTMLAttributes, type ReactNode } from 'react'

function subscribe(cb: () => void) {
  window.addEventListener('hashchange', cb)
  return () => window.removeEventListener('hashchange', cb)
}

const getSnapshot = () => window.location.hash.replace(/^#/, '') || '/'

export type Route =
  | { name: 'home' }
  | { name: 'create' }
  | { name: 'raffle'; id: bigint }
  | { name: 'mine' }
  | { name: 'winners' }
  | { name: 'fair' }
  | { name: 'notfound' }

export function parseRoute(path: string): Route {
  const clean = path.split('?')[0].replace(/\/+$/, '') || '/'
  if (clean === '/') return { name: 'home' }
  if (clean === '/create') return { name: 'create' }
  if (clean === '/mine') return { name: 'mine' }
  if (clean === '/winners') return { name: 'winners' }
  if (clean === '/fair') return { name: 'fair' }
  const m = clean.match(/^\/raffle\/(\d+)$/)
  if (m) return { name: 'raffle', id: BigInt(m[1]) }
  return { name: 'notfound' }
}

export function useRoute(): Route {
  const path = useSyncExternalStore(subscribe, getSnapshot, () => '/')
  useEffect(() => {
    window.scrollTo({ top: 0 })
  }, [path])
  return parseRoute(path)
}

export function navigate(path: string) {
  window.location.hash = path
}

interface LinkProps extends Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href'> {
  to: string
  children: ReactNode
}

export function Link({ to, children, ...rest }: LinkProps) {
  return (
    <a href={`#${to}`} {...rest}>
      {children}
    </a>
  )
}
