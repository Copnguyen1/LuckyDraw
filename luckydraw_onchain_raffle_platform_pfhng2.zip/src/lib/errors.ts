import { BaseError, ContractFunctionRevertedError, UserRejectedRequestError } from 'viem'

const CONTRACT_ERRORS: Record<string, string> = {
  EnforcedPause: 'The platform is paused right now. Try again soon.',
  InvalidDuration: 'Duration must be between 1 minute and 30 days.',
  InvalidMaxTickets: 'Max tickets must be between 2 and 1,000.',
  InvalidTicketPrice: 'Ticket price must be at least 0.01 USDC.',
  InvalidQuantity: 'Choose at least one ticket.',
  NotEnoughTickets: 'Not enough tickets left for that quantity.',
  NotReadyToDraw: 'This raffle is not ready to draw yet.',
  NothingToClaim: 'There is nothing to claim.',
  RaffleNotActive: 'This raffle is no longer active.',
  RaffleNotFound: 'That raffle does not exist.',
  SalesEnded: 'Ticket sales for this raffle have ended.',
  SameBlockAsLastPurchase: 'The last ticket was bought in this block. Wait a moment and draw again.',
  SafeERC20FailedOperation: 'USDC transfer failed. Check your balance and allowance.',
}

export interface ParsedTxError {
  rejected: boolean
  message: string
}

export function parseTxError(error: unknown): ParsedTxError {
  if (error instanceof BaseError) {
    if (error.walk((e) => e instanceof UserRejectedRequestError)) {
      return { rejected: true, message: 'Transaction cancelled.' }
    }
    const reverted = error.walk((e) => e instanceof ContractFunctionRevertedError)
    if (reverted instanceof ContractFunctionRevertedError) {
      const name = reverted.data?.errorName
      if (name && CONTRACT_ERRORS[name]) return { rejected: false, message: CONTRACT_ERRORS[name] }
    }
  }
  const text = (error instanceof Error ? error.message : String(error)).toLowerCase()
  if (text.includes('user rejected') || text.includes('user denied') || text.includes('rejected the request')) {
    return { rejected: true, message: 'Transaction cancelled.' }
  }
  if (text.includes('insufficient funds') || text.includes('exceeds balance')) {
    return { rejected: false, message: 'Insufficient USDC for this transaction plus network fees. Add USDC to your wallet and try again.' }
  }
  if (text.includes('exceeds allowance') || text.includes('insufficient allowance')) {
    return { rejected: false, message: 'USDC allowance is too low. Approve the amount first.' }
  }
  if (text.includes('network') || text.includes('timeout') || text.includes('fetch')) {
    return { rejected: false, message: 'Network issue. Check your connection and retry.' }
  }
  if (text.includes('reverted')) {
    return { rejected: false, message: 'The transaction was rejected by the contract. Refresh and try again.' }
  }
  return { rejected: false, message: 'Something went wrong. Please try again.' }
}
