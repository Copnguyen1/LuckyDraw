import type { Address } from 'viem'
import { arc } from 'viem/chains'
import { buildAddressExplorerUrl, buildTxExplorerUrl, getUsdc, requireChain } from '@/onchain-facts'
import { luckyDrawAbi } from './abi'

export const CHAIN = arc
export const CHAIN_ID = arc.id
export const CHAIN_NAME = 'Arc Mainnet'
/** Public RPC for Arc Mainnet, read from the generated onchain facts. */
export const CHAIN_RPC = requireChain(CHAIN_ID).rpcUrls[0]

const rawAddress = import.meta.env.VITE_LUCKYDRAW_ADDRESS as string | undefined
if (!rawAddress || !/^0x[0-9a-fA-F]{40}$/.test(rawAddress)) {
  throw new Error('VITE_LUCKYDRAW_ADDRESS is missing or invalid in .env')
}
export const LUCKYDRAW_ADDRESS = rawAddress as Address

const usdcFact = getUsdc(CHAIN_ID)
if (!usdcFact) {
  throw new Error('USDC is not registered for Arc Mainnet')
}
export const USDC_ADDRESS = usdcFact.address as Address
export const USDC_DECIMALS = usdcFact.decimals

export const luckyDraw = { address: LUCKYDRAW_ADDRESS, abi: luckyDrawAbi, chainId: CHAIN_ID } as const

/** Limits enforced by the deployed contract. */
export const LIMITS = {
  minTicketPrice: 10_000n, // 0.01 USDC (6 decimals)
  minTickets: 2,
  maxTickets: 1000,
  minDurationSec: 60,
  maxDurationSec: 30 * 24 * 3600,
} as const

export const txUrl = (hash: string) => buildTxExplorerUrl(CHAIN_ID, hash)
export const addressUrl = (address: string) => buildAddressExplorerUrl(CHAIN_ID, address)
export const blockUrl = (block: bigint | number) => `${requireChain(CHAIN_ID).explorerBase}/block/${block.toString()}`

/** Raw struct returned by the contract (status: 0 Active, 1 Drawn, 2 Cancelled). */
export interface RaffleStruct {
  creator: Address
  ticketPrice: bigint
  maxTickets: number
  ticketsSold: number
  createdAt: bigint
  endTime: bigint
  drawnAt: bigint
  feeBps: number
  status: number
  winner: Address
  winningTicket: number
  pot: bigint
  fee: bigint
  payout: bigint
  drawBlock: bigint
  lastPurchaseBlock: bigint
}

export interface Raffle extends RaffleStruct {
  id: bigint
}

export type RaffleView = 'active' | 'ready' | 'expired' | 'drawn' | 'cancelled'

/** Derives the UI state of a raffle from its stored state and the chain clock (unix seconds). */
export function deriveView(r: RaffleStruct, now: number): RaffleView {
  if (r.status === 1) return 'drawn'
  if (r.status === 2) return 'cancelled'
  const over = now >= Number(r.endTime)
  const soldOut = r.ticketsSold >= r.maxTickets
  if (soldOut) return 'ready'
  if (over) return r.ticketsSold === 0 ? 'expired' : 'ready'
  return 'active'
}

export const VIEW_LABEL: Record<RaffleView, string> = {
  active: 'Live',
  ready: 'Ready to draw',
  expired: 'Ended, no tickets',
  drawn: 'Drawn',
  cancelled: 'Closed',
}

