import { useMemo, useState } from 'react'
import { parseEventLogs } from 'viem'
import { useWriteContract } from 'wagmi'
import { toast } from 'sonner'
import { Clock, Sparkles, Ticket, Trophy } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { Disclaimer } from '@/components/Disclaimer'
import { PageHeading, Spinner, TxNotice } from '@/components/ui'
import { WalletGate } from '@/components/WalletButton'
import { useContractTx } from '@/hooks/useContractTx'
import { useFeeBps } from '@/hooks/useRaffles'
import { LIMITS, luckyDraw } from '@/lib/contract'
import { formatDate, formatDuration, usdc } from '@/lib/format'
import { navigate } from '@/lib/router'
import { parseUsdc } from '@/onchain-money'
import { luckyDrawAbi } from '@/lib/abi'

const DURATIONS = [
  { label: '5 min', sec: 300 },
  { label: '1 hour', sec: 3600 },
  { label: '6 hours', sec: 6 * 3600 },
  { label: '1 day', sec: 86400 },
  { label: '3 days', sec: 3 * 86400 },
  { label: '7 days', sec: 7 * 86400 },
]
const UNITS = { minutes: 60, hours: 3600, days: 86400 } as const
type Unit = keyof typeof UNITS

function Field({ label, hint, error, children }: { label: string; hint?: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between">
        <span className="label">{label}</span>
        {hint ? <span className="text-xs text-white/35">{hint}</span> : null}
      </div>
      {children}
      {error ? <p className="mt-1.5 text-xs text-rose-450">{error}</p> : null}
    </div>
  )
}

export function Create() {
  const feeBps = useFeeBps()
  const { writeContractAsync } = useWriteContract()
  const tx = useContractTx()

  const [price, setPrice] = useState('1')
  const [maxTickets, setMaxTickets] = useState('50')
  const [presetSec, setPresetSec] = useState<number | null>(86400)
  const [customAmount, setCustomAmount] = useState('30')
  const [customUnit, setCustomUnit] = useState<Unit>('minutes')
  const [touched, setTouched] = useState(false)

  const parsed = useMemo(() => {
    let priceRaw: bigint | null = null
    let priceError: string | undefined
    try {
      priceRaw = price.trim() ? parseUsdc(price.trim()) : null
      if (priceRaw === null) priceError = 'Enter a ticket price.'
      else if (priceRaw < LIMITS.minTicketPrice) priceError = 'Minimum ticket price is 0.01 USDC.'
    } catch {
      priceError = 'Enter a valid amount, up to 6 decimals.'
    }

    const max = Number(maxTickets)
    let maxError: string | undefined
    if (!maxTickets.trim() || !Number.isInteger(max)) maxError = 'Enter a whole number.'
    else if (max < LIMITS.minTickets || max > LIMITS.maxTickets)
      maxError = `Choose between ${LIMITS.minTickets} and ${LIMITS.maxTickets.toLocaleString()} tickets.`

    let duration = presetSec ?? 0
    let durationError: string | undefined
    if (presetSec === null) {
      const n = Number(customAmount)
      duration = Number.isFinite(n) ? Math.round(n * UNITS[customUnit]) : 0
      if (!customAmount.trim() || !Number.isFinite(n) || n <= 0) durationError = 'Enter a duration.'
      else if (duration < LIMITS.minDurationSec) durationError = 'Minimum duration is 1 minute.'
      else if (duration > LIMITS.maxDurationSec) durationError = 'Maximum duration is 30 days.'
    }

    const valid = !priceError && !maxError && !durationError && priceRaw !== null
    return { priceRaw, priceError, max, maxError, duration, durationError, valid }
  }, [price, maxTickets, presetSec, customAmount, customUnit])

  const maxPot = parsed.priceRaw !== null && !parsed.maxError ? parsed.priceRaw * BigInt(parsed.max) : 0n
  const fee = (maxPot * BigInt(feeBps)) / 10_000n
  const endsAt = Math.floor(Date.now() / 1000) + parsed.duration

  const submit = async () => {
    setTouched(true)
    if (!parsed.valid || parsed.priceRaw === null) return
    const priceRaw = parsed.priceRaw
    const receipt = await tx.run(() =>
      writeContractAsync({
        ...luckyDraw,
        functionName: 'createRaffle',
        args: [priceRaw, parsed.max, BigInt(parsed.duration)],
      }),
    )
    if (!receipt) return
    const logs = parseEventLogs({ abi: luckyDrawAbi, eventName: 'RaffleCreated', logs: receipt.logs })
    const id = logs[0]?.args.id
    toast.success('Raffle created')
    if (id !== undefined) navigate(`/raffle/${id.toString()}`)
  }

  const showErr = touched

  return (
    <div className="mx-auto max-w-5xl">
      <PageHeading
        eyebrow="New raffle"
        title="Create a raffle"
        subtitle="Set the rules once. Everything is enforced by the contract: tickets, deadline, draw, and payout."
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <div className="card min-w-0 space-y-7 p-5 sm:p-6">
          <Field label="Ticket price" hint="USDC per ticket" error={showErr ? parsed.priceError : undefined}>
            <div className="relative">
              <input
                className="input pr-24 num"
                inputMode="decimal"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                aria-invalid={showErr && !!parsed.priceError}
                placeholder="1.00"
                disabled={tx.busy}
              />
              <span className="pointer-events-none absolute right-4 top-1/2 flex -translate-y-1/2 items-center gap-1.5 text-sm text-white/50">
                <TokenUSDC variant="branded" size={16} /> USDC
              </span>
            </div>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {['0.1', '1', '5', '10', '25'].map((v) => (
                <button key={v} className="chip" data-active={price === v} onClick={() => setPrice(v)} disabled={tx.busy}>
                  {v}
                </button>
              ))}
            </div>
          </Field>

          <Field
            label="Maximum tickets"
            hint={`${LIMITS.minTickets} to ${LIMITS.maxTickets.toLocaleString()}`}
            error={showErr ? parsed.maxError : undefined}
          >
            <input
              className="input num"
              inputMode="numeric"
              value={maxTickets}
              onChange={(e) => setMaxTickets(e.target.value.replace(/[^\d]/g, ''))}
              aria-invalid={showErr && !!parsed.maxError}
              placeholder="50"
              disabled={tx.busy}
            />
            <div className="mt-2.5 flex flex-wrap gap-2">
              {['10', '25', '50', '100', '500'].map((v) => (
                <button key={v} className="chip" data-active={maxTickets === v} onClick={() => setMaxTickets(v)} disabled={tx.busy}>
                  {v}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Duration" hint="Raffle can also end early if it sells out" error={showErr ? parsed.durationError : undefined}>
            <div className="flex flex-wrap gap-2">
              {DURATIONS.map((d) => (
                <button key={d.sec} className="chip" data-active={presetSec === d.sec} onClick={() => setPresetSec(d.sec)} disabled={tx.busy}>
                  {d.label}
                </button>
              ))}
              <button className="chip" data-active={presetSec === null} onClick={() => setPresetSec(null)} disabled={tx.busy}>
                Custom
              </button>
            </div>
            {presetSec === null ? (
              <div className="mt-3 grid grid-cols-[1fr_auto] gap-2">
                <input
                  className="input num"
                  inputMode="decimal"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  aria-invalid={showErr && !!parsed.durationError}
                  aria-label="Custom duration"
                  disabled={tx.busy}
                />
                <select
                  className="input !w-auto"
                  value={customUnit}
                  onChange={(e) => setCustomUnit(e.target.value as Unit)}
                  aria-label="Duration unit"
                  disabled={tx.busy}
                >
                  <option value="minutes">minutes</option>
                  <option value="hours">hours</option>
                  <option value="days">days</option>
                </select>
              </div>
            ) : null}
          </Field>
        </div>

        <div className="min-w-0 space-y-4">
          <div className="card relative overflow-hidden p-5 sm:p-6">
            <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-gold-400/10 blur-3xl" />
            <div className="label !text-gold-400/80">Preview</div>
            <div className="mt-3">
              <div className="label">Pot when sold out</div>
              <div className="display num mt-1 text-4xl font-bold text-white">
                {maxPot > 0n ? usdc(maxPot) : '0.00'} <span className="text-base font-medium text-white/45">USDC</span>
              </div>
            </div>
            <dl className="mt-5 space-y-3 border-t border-white/[0.06] pt-4 text-sm">
              <div className="flex justify-between">
                <dt className="flex items-center gap-2 text-white/55">
                  <Trophy size={14} /> Winner receives
                </dt>
                <dd className="num font-semibold text-neon-400">{maxPot > 0n ? usdc(maxPot - fee) : '0.00'} USDC</dd>
              </div>
              <div className="flex justify-between">
                <dt className="flex items-center gap-2 text-white/55">
                  <Sparkles size={14} /> Platform fee ({(feeBps / 100).toFixed(feeBps % 100 === 0 ? 0 : 1)}%)
                </dt>
                <dd className="num text-white/80">{maxPot > 0n ? usdc(fee) : '0.00'} USDC</dd>
              </div>
              <div className="flex justify-between">
                <dt className="flex items-center gap-2 text-white/55">
                  <Ticket size={14} /> Tickets
                </dt>
                <dd className="num text-white/80">{parsed.maxError ? '-' : parsed.max.toLocaleString()}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="flex items-center gap-2 text-white/55">
                  <Clock size={14} /> Ends
                </dt>
                <dd className="num text-right text-white/80">
                  {parsed.duration > 0 && !parsed.durationError ? (
                    <>
                      {formatDate(endsAt)}
                      <span className="block text-xs text-white/40">in {formatDuration(parsed.duration)}</span>
                    </>
                  ) : (
                    '-'
                  )}
                </dd>
              </div>
            </dl>
          </div>

          <WalletGate prompt="Connect your wallet to create a raffle.">
            <button className="btn-gold w-full" onClick={() => void submit()} disabled={tx.busy}>
              {tx.busy ? <Spinner /> : <Sparkles size={16} />}
              {tx.phase === 'wallet' ? 'Confirm in wallet' : tx.phase === 'confirming' ? 'Creating raffle' : 'Create raffle'}
            </button>
          </WalletGate>
          <TxNotice phase={tx.phase} hash={tx.hash} error={tx.error} successText={'Raffle created. Opening it now\u2026'} />
          <p className="text-xs text-white/40">
            Creating a raffle only costs network fees. You are not required to buy tickets in your own raffle.
          </p>
        </div>
      </div>

      <div className="mt-8">
        <Disclaimer compact />
      </div>
    </div>
  )
}
