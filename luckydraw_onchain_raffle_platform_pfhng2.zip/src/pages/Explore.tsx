import { useMemo, useState, type ReactNode } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Flame, Sparkles, Ticket, Trophy, Wallet } from 'lucide-react'
import { RaffleCard, RaffleCardSkeleton } from '@/components/RaffleCard'
import { Disclaimer } from '@/components/Disclaimer'
import { EmptyState, ErrorState } from '@/components/ui'
import { useChainNow } from '@/hooks/useClock'
import { useRaffles } from '@/hooks/useRaffles'
import { deriveView } from '@/lib/contract'
import { usdc } from '@/lib/format'
import { Link } from '@/lib/router'

type Filter = 'live' | 'ready' | 'finished' | 'all'

const FILTERS: { id: Filter; label: string }[] = [
  { id: 'live', label: 'Live' },
  { id: 'ready', label: 'Ready to draw' },
  { id: 'finished', label: 'Finished' },
  { id: 'all', label: 'All' },
]

function StatRow({ icon, label, value, suffix }: { icon: ReactNode; label: string; value: string; suffix?: string }) {
  return (
    <div className="flex items-center gap-4 rounded-2xl border border-white/[0.06] bg-ink-900/70 px-4 py-3.5">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gold-400/10 text-gold-300">{icon}</div>
      <div className="min-w-0">
        <div className="label">{label}</div>
        <div className="display num mt-0.5 flex flex-wrap items-baseline gap-x-1.5 text-2xl font-bold leading-tight text-white">
          {value}
          {suffix ? <span className="text-sm font-medium text-white/45">{suffix}</span> : null}
        </div>
      </div>
    </div>
  )
}

function CardGrid({ children }: { children: ReactNode }) {
  return <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-3">{children}</div>
}

export function Explore() {
  const { raffles, isLoading, isError, refetch } = useRaffles()
  const now = useChainNow()
  const [filter, setFilter] = useState<Filter>('live')

  const withView = useMemo(() => raffles.map((r) => ({ r, view: deriveView(r, now) })), [raffles, now])

  const stats = useMemo(() => {
    let inPlay = 0n
    let paid = 0n
    let live = 0
    for (const { r, view } of withView) {
      if (view === 'active' || view === 'ready') {
        inPlay += r.ticketPrice * BigInt(r.ticketsSold)
        if (view === 'active') live += 1
      }
      if (view === 'drawn') paid += r.payout
    }
    return { inPlay, paid, live }
  }, [withView])

  const ready = useMemo(() => withView.filter((x) => x.view === 'ready'), [withView])

  const filtered = useMemo(() => {
    return withView.filter(({ view }) => {
      if (filter === 'all') return true
      if (filter === 'live') return view === 'active'
      if (filter === 'ready') return view === 'ready'
      return view === 'drawn' || view === 'cancelled' || view === 'expired'
    })
  }, [withView, filter])

  return (
    <div className="space-y-12">
      <section className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-ink-800/60 p-6 sm:p-10">
        <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-gold-400/12 blur-3xl" />
        <div className="relative grid items-center gap-8 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)] lg:gap-12">
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
            <div className="label !text-gold-400/90">Onchain raffles on Arc Mainnet</div>
            <h1 className="display mt-3 text-4xl font-bold leading-[1.1] text-white sm:text-5xl">
              One ticket. <span className="gold-text">One winner takes the pot.</span>
            </h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-white/60">
              Start a raffle in seconds or buy tickets with USDC. When time is up or tickets sell out, anyone can draw the
              winner and the contract pays out instantly.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/create" className="btn-gold">
                Create a raffle <ArrowRight size={16} />
              </Link>
              <Link to="/fair" className="btn-ghost">
                How the draw works
              </Link>
            </div>
          </motion.div>

          <div className="grid gap-3">
            <StatRow icon={<Flame size={20} />} label="Live raffles" value={String(stats.live)} />
            <StatRow icon={<Wallet size={20} />} label="Total in play" value={usdc(stats.inPlay)} suffix="USDC" />
            <StatRow icon={<Trophy size={20} />} label="Paid to winners" value={usdc(stats.paid)} suffix="USDC" />
          </div>
        </div>
      </section>

      {ready.length > 0 ? (
        <section>
          <div className="mb-5 flex items-center gap-3">
            <Sparkles size={20} className="shrink-0 text-gold-300" />
            <h2 className="display text-2xl font-semibold text-white">Ready to draw</h2>
            <span className="rounded-full bg-gold-400 px-2 py-0.5 text-xs font-bold text-ink-950">{ready.length}</span>
          </div>
          <CardGrid>
            {ready.map(({ r }, i) => (
              <RaffleCard key={r.id.toString()} raffle={r} index={i} />
            ))}
          </CardGrid>
        </section>
      ) : null}

      <section>
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <h2 className="display text-2xl font-semibold text-white">Explore raffles</h2>
          <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter raffles">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                role="tab"
                aria-selected={filter === f.id}
                data-active={filter === f.id}
                className="chip whitespace-nowrap"
                onClick={() => setFilter(f.id)}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {isError ? (
          <ErrorState message="Could not load raffles from Arc Mainnet." onRetry={() => void refetch()} />
        ) : isLoading ? (
          <CardGrid>
            {Array.from({ length: 6 }).map((_, i) => (
              <RaffleCardSkeleton key={i} />
            ))}
          </CardGrid>
        ) : raffles.length === 0 ? (
          <EmptyState
            icon={<Ticket size={26} />}
            title="No raffles yet"
            body="Be the first. Set a ticket price, a ticket cap and an end time, and your raffle goes live onchain."
            action={
              <Link to="/create" className="btn-gold">
                Create the first raffle
              </Link>
            }
          />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon={<Ticket size={26} />}
            title={filter === 'live' ? 'No live raffles right now' : filter === 'ready' ? 'Nothing waiting for a draw' : 'Nothing here yet'}
            body="Check another tab, or start a raffle of your own."
            action={
              <Link to="/create" className="btn-gold">
                Create a raffle
              </Link>
            }
          />
        ) : (
          <CardGrid>
            {filtered.map(({ r }, i) => (
              <RaffleCard key={r.id.toString()} raffle={r} index={i} />
            ))}
          </CardGrid>
        )}
      </section>

      <Disclaimer />
    </div>
  )
}
