import { useMemo } from 'react'
import { useAccount } from 'wagmi'
import { ArrowUpRight, Crown, Trophy } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { EmptyState, ErrorState, PageHeading, Skeleton } from '@/components/ui'
import { useRaffles } from '@/hooks/useRaffles'
import { addressUrl } from '@/lib/contract'
import { formatDate, shortAddr, usdc } from '@/lib/format'
import { Link } from '@/lib/router'

export function Winners() {
  const { address } = useAccount()
  const { raffles, isLoading, isError, refetch } = useRaffles()

  const drawn = useMemo(
    () => raffles.filter((r) => r.status === 1).sort((a, b) => Number(b.drawnAt - a.drawnAt)),
    [raffles],
  )
  const totalPaid = drawn.reduce((s, r) => s + r.payout, 0n)
  const biggest = drawn.reduce((m, r) => (r.payout > m ? r.payout : m), 0n)

  return (
    <div>
      <PageHeading eyebrow="Hall of fame" title="Past winners" subtitle="Every completed raffle, with the winner and the prize that was paid out by the contract." />

      {isError ? (
        <ErrorState message="Could not load past winners." onRetry={() => void refetch()} />
      ) : isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      ) : drawn.length === 0 ? (
        <EmptyState
          icon={<Trophy size={26} />}
          title="No winners yet"
          body="The first completed draw will appear here with its winner and prize."
          action={
            <Link to="/" className="btn-gold">
              Find a raffle
            </Link>
          }
        />
      ) : (
        <>
          <div className="mb-6 grid gap-3 sm:grid-cols-3">
            <div className="card px-5 py-4">
              <div className="label">Completed draws</div>
              <div className="display num text-2xl font-bold text-white">{drawn.length}</div>
            </div>
            <div className="card px-5 py-4">
              <div className="label">Total paid out</div>
              <div className="display num text-2xl font-bold text-neon-400">{usdc(totalPaid)} USDC</div>
            </div>
            <div className="card px-5 py-4">
              <div className="label">Biggest prize</div>
              <div className="display num text-2xl font-bold text-gold-300">{usdc(biggest)} USDC</div>
            </div>
          </div>

          <ul className="space-y-3">
            {drawn.map((r) => {
              const mine = !!address && r.winner.toLowerCase() === address.toLowerCase()
              return (
                <li key={r.id.toString()}>
                  <Link
                    to={`/raffle/${r.id.toString()}`}
                    className={`card card-hover flex flex-wrap items-center justify-between gap-4 p-4 ${mine ? '!border-gold-400/40' : ''}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold-400/10 text-gold-300">
                        {r.payout === biggest ? <Crown size={20} /> : <Trophy size={20} />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="mono-addr font-semibold text-white">{shortAddr(r.winner)}</span>
                          {mine ? <span className="rounded-full bg-gold-400/15 px-2 py-0.5 text-[11px] font-semibold text-gold-300">You</span> : null}
                        </div>
                        <div className="num mt-0.5 text-sm text-white/50">
                          Raffle #{r.id.toString()} · ticket #{r.winningTicket + 1} of {r.ticketsSold} · {formatDate(r.drawnAt)}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <a
                        href={addressUrl(r.winner)}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="hidden text-xs text-white/40 hover:text-gold-300 sm:inline"
                      >
                        Winner on explorer
                      </a>
                      <div className="display num flex items-center gap-1.5 text-xl font-bold text-neon-400">
                        +{usdc(r.payout)} <TokenUSDC variant="branded" size={18} />
                      </div>
                      <ArrowUpRight size={16} className="text-white/30" />
                    </div>
                  </Link>
                </li>
              )
            })}
          </ul>
        </>
      )}
    </div>
  )
}
