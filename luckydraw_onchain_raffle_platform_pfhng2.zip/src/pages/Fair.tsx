import { ExternalLink, Dices, Layers, Ticket, Trophy } from 'lucide-react'
import { Disclaimer } from '@/components/Disclaimer'
import { PageHeading } from '@/components/ui'
import { useFeeBps } from '@/hooks/useRaffles'
import { useReadContract } from 'wagmi'
import { CHAIN_NAME, LIMITS, LUCKYDRAW_ADDRESS, addressUrl, luckyDraw } from '@/lib/contract'
import { shortAddr } from '@/lib/format'

const STEPS = [
  { icon: Layers, title: 'Create', body: 'Anyone sets a ticket price, a ticket cap and a deadline. The rules are locked into the contract.' },
  { icon: Ticket, title: 'Buy tickets', body: 'Players pay in USDC. Each ticket is one entry, and more tickets mean better odds.' },
  { icon: Dices, title: 'Draw', body: 'When time is up or every ticket is sold, anyone can press Draw. No admin is needed.' },
  { icon: Trophy, title: 'Get paid', body: 'The contract picks a ticket, pays the pot minus the platform fee to its owner, sends the fee to the fee wallet, and records the result.' },
]

export function Fair() {
  const feeBps = useFeeBps()
  const treasuryQ = useReadContract({ ...luckyDraw, functionName: 'treasury', query: { staleTime: 300_000 } })
  const feeWallet = treasuryQ.data
  return (
    <div className="mx-auto max-w-3xl">
      <PageHeading
        eyebrow="Fair play"
        title="How LuckyDraw works"
        subtitle="Plain rules, onchain payouts, and an honest note about how the winner is chosen."
      />

      <div className="grid gap-3 sm:grid-cols-2">
        {STEPS.map((s, i) => (
          <div key={s.title} className="card p-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold-400/10 text-gold-300">
                <s.icon size={18} />
              </div>
              <div className="display text-lg font-semibold text-white">
                <span className="num mr-2 text-white/30">{i + 1}</span>
                {s.title}
              </div>
            </div>
            <p className="mt-3 text-sm text-white/60">{s.body}</p>
          </div>
        ))}
      </div>

      <section className="card mt-6 p-6">
        <h2 className="display text-xl font-semibold text-white">How the winner is chosen</h2>
        <div className="mt-3 space-y-3 text-sm leading-relaxed text-white/65">
          <p>
            When the draw transaction runs, the contract hashes the previous block hash together with the raffle id and
            the number of tickets sold. That number, taken modulo the tickets sold, selects one winning ticket, and the
            wallet holding it receives the pot.
          </p>
          <p>
            A draw cannot happen in the same block as the last ticket purchase, which stops buyers from seeing the
            result before they commit. If the winner cannot receive USDC (for example a blocked address), the prize is
            held in the contract for them to claim, so a draw can never get stuck.
          </p>
        </div>
      </section>

      <div className="mt-6">
        <Disclaimer />
      </div>

      <section className="card mt-6 p-6">
        <h2 className="display text-xl font-semibold text-white">Current limitations</h2>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-white/65 marker:text-gold-400/70">
          <li>Block hashes are not a secure source of randomness. Block producers can influence them.</li>
          <li>
            Someone holding tickets can simulate the draw offline and only submit it when they would win. Other players
            can draw first, but nothing forces them to.
          </li>
          <li>This app runs on {CHAIN_NAME} with real USDC. Treat the randomness as manipulable and only play with money you can afford to lose.</li>
          <li>The contract has not been through a third-party security audit.</li>
        </ul>
      </section>

      <section className="card mt-6 p-6">
        <h2 className="display text-xl font-semibold text-white">Contract and limits</h2>
        <dl className="mt-4 grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Network</dt>
            <dd className="text-white">{CHAIN_NAME}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Contract</dt>
            <dd>
              <a href={addressUrl(LUCKYDRAW_ADDRESS)} target="_blank" rel="noopener noreferrer" className="mono-addr inline-flex items-center gap-1 text-gold-300 hover:underline">
                {shortAddr(LUCKYDRAW_ADDRESS)} <ExternalLink size={12} />
              </a>
            </dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Platform fee</dt>
            <dd className="num text-white">{feeBps / 100}% of the pot</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Fee wallet</dt>
            <dd>
              {feeWallet ? (
                <a href={addressUrl(feeWallet)} target="_blank" rel="noopener noreferrer" className="mono-addr inline-flex items-center gap-1 text-gold-300 hover:underline">
                  {shortAddr(feeWallet)} <ExternalLink size={12} />
                </a>
              ) : (
                <span className="text-white/40">Unavailable</span>
              )}
            </dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Ticket price</dt>
            <dd className="num text-white">from 0.01 USDC</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Tickets per raffle</dt>
            <dd className="num text-white">
              {LIMITS.minTickets} to {LIMITS.maxTickets.toLocaleString()}
            </dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-white/50">Duration</dt>
            <dd className="num text-white">1 minute to 30 days</dd>
          </div>
        </dl>
      </section>
    </div>
  )
}
