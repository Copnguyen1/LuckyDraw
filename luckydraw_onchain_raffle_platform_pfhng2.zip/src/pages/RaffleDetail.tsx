import { useCallback, useMemo, useState } from 'react'
import { AnimatePresence } from 'framer-motion'
import { useAccount } from 'wagmi'
import { ArrowLeft, Coins, ExternalLink, Percent, RotateCcw, Ticket, Timer, Trophy, Users } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { BuyPanel } from '@/components/BuyPanel'
import { Disclaimer } from '@/components/Disclaimer'
import { DrawPanel } from '@/components/DrawPanel'
import { DrawStage } from '@/components/DrawStage'
import { BigCountdown, EmptyState, ErrorState, ProgressBar, Skeleton, StatusBadge } from '@/components/ui'
import { useChainNow } from '@/hooks/useClock'
import { useParticipants, useRaffle } from '@/hooks/useRaffles'
import { addressUrl, blockUrl, deriveView, type Raffle } from '@/lib/contract'
import { formatDate, pct, shortAddr, usdc, usdcSmart } from '@/lib/format'
import { Link } from '@/lib/router'

function InfoTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-white/[0.06] bg-ink-900/60 p-3.5">
      <div className="flex items-center gap-1.5 text-white/45">
        {icon}
        <span className="label !text-[10px]">{label}</span>
      </div>
      <div className="display num mt-1.5 break-words text-lg font-semibold leading-tight text-white">{value}</div>
    </div>
  )
}

function WinnerCard({ raffle, me, onReplay }: { raffle: Raffle; me?: string; onReplay: () => void }) {
  const iWon = !!me && me.toLowerCase() === raffle.winner.toLowerCase()
  return (
    <div className="card relative overflow-hidden border-gold-400/30 p-6">
      <div className="pointer-events-none absolute -right-16 -top-16 h-52 w-52 rounded-full bg-gold-400/15 blur-3xl" />
      <div className="relative">
        <div className="flex items-center gap-2">
          <Trophy className="text-gold-300" size={18} />
          <span className="label !text-gold-400/90">{iWon ? 'You won this raffle' : 'Winner'}</span>
        </div>
        <a
          href={addressUrl(raffle.winner)}
          target="_blank"
          rel="noopener noreferrer"
          className="mono-addr mt-3 inline-flex max-w-full items-center gap-1.5 break-all text-lg font-semibold text-white hover:text-gold-300"
        >
          {raffle.winner} <ExternalLink size={14} className="shrink-0" />
        </a>
        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <div>
            <div className="label">Prize paid</div>
            <div className="display num mt-0.5 flex items-center gap-1.5 text-2xl font-bold text-neon-400">
              {usdc(raffle.payout)} <TokenUSDC variant="branded" size={18} />
            </div>
          </div>
          <div>
            <div className="label">Winning ticket</div>
            <div className="display num mt-0.5 text-2xl font-bold text-white">
              #{raffle.winningTicket + 1}
              <span className="ml-1 text-sm font-medium text-white/40">of {raffle.ticketsSold}</span>
            </div>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-x-5 gap-y-1 text-xs text-white/45">
          <span>Pot {usdc(raffle.pot)} USDC</span>
          <span>Fee {usdc(raffle.fee)} USDC</span>
          <span>Drawn {formatDate(raffle.drawnAt)}</span>
          <a href={blockUrl(raffle.drawBlock)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 hover:text-gold-300">
            Block {raffle.drawBlock.toString()} <ExternalLink size={10} />
          </a>
        </div>
        <button className="btn-ghost btn-sm mt-5" onClick={onReplay}>
          <RotateCcw size={14} /> Replay the draw
        </button>
      </div>
    </div>
  )
}

export function RaffleDetail({ id }: { id: bigint }) {
  const { address } = useAccount()
  const now = useChainNow()
  const { raffle, isLoading, isError, refetch } = useRaffle(id)
  const { participants, refetch: refetchParticipants } = useParticipants(id, raffle?.ticketsSold ?? 0)
  const [drawSession, setDrawSession] = useState(false)
  const [replay, setReplay] = useState(false)

  const refresh = useCallback(() => {
    void refetch()
    void refetchParticipants()
  }, [refetch, refetchParticipants])

  const view = raffle ? deriveView(raffle, now) : undefined
  const participantAddrs = useMemo(() => participants.map((p) => p.address), [participants])
  const sortedParticipants = useMemo(() => [...participants].sort((a, b) => b.tickets - a.tickets), [participants])

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-6 w-32" />
        <Skeleton className="h-64 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    )
  }

  if (isError || !raffle || !view) {
    return (
      <div className="space-y-4">
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-white/60 hover:text-white">
          <ArrowLeft size={14} /> All raffles
        </Link>
        <ErrorState message={`Raffle #${id.toString()} could not be found on Arc Mainnet.`} onRetry={() => void refetch()} />
      </div>
    )
  }

  const pot = raffle.ticketPrice * BigInt(raffle.ticketsSold)
  const maxPot = raffle.ticketPrice * BigInt(raffle.maxTickets)
  const progress = pct(raffle.ticketsSold, raffle.maxTickets)
  const remaining = raffle.maxTickets - raffle.ticketsSold
  const showDraw = view === 'ready' || view === 'expired' || drawSession
  const isCreator = !!address && address.toLowerCase() === raffle.creator.toLowerCase()

  return (
    <div>
      <Link to="/" className="mb-5 inline-flex items-center gap-1.5 text-sm text-white/60 hover:text-white">
        <ArrowLeft size={14} /> All raffles
      </Link>

      <div className="mb-6 flex flex-wrap items-center gap-3">
        <h1 className="display text-3xl font-bold leading-tight text-white sm:text-4xl">Raffle #{raffle.id.toString()}</h1>
        <StatusBadge view={view} />
        {isCreator ? <span className="rounded-full border border-white/10 px-2.5 py-1 text-xs text-white/60">You created this</span> : null}
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px] xl:grid-cols-[minmax(0,1fr)_400px]">
        <div className="min-w-0 space-y-6">
          <div className="card p-5 sm:p-6">
            <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-4">
              <div>
                <div className="label">{view === 'drawn' ? 'Final pot' : 'Current pot'}</div>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="display num text-4xl font-bold leading-none text-white sm:text-5xl">{usdcSmart(view === 'drawn' ? raffle.pot : pot)}</span>
                  <span className="flex items-center gap-1.5 text-base font-medium text-white/50">
                    <TokenUSDC variant="branded" size={20} /> USDC
                  </span>
                </div>
                <div className="mt-1 text-sm text-white/45">
                  {view === 'drawn' ? `${raffle.feeBps / 100}% platform fee was taken` : `Up to ${usdc(maxPot)} USDC when sold out`}
                </div>
              </div>
              <div className="text-sm text-white/50">
                Created by
                <a
                  href={addressUrl(raffle.creator)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mono-addr ml-1.5 inline-flex items-center gap-1 text-white/80 hover:text-gold-300"
                >
                  {shortAddr(raffle.creator)} <ExternalLink size={11} />
                </a>
              </div>
            </div>

            <div className="mt-6">
              <div className="mb-2 flex justify-between text-sm">
                <span className="num text-white/70">
                  <span className="font-semibold text-white">{raffle.ticketsSold}</span> of {raffle.maxTickets} tickets sold
                </span>
                <span className="num text-white/45">{Math.round(progress)}%</span>
              </div>
              <ProgressBar value={progress} tone={view === 'active' ? 'gold' : 'neon'} />
            </div>

            {view === 'active' ? (
              <div className="mt-6">
                <div className="label mb-2">Time remaining</div>
                <BigCountdown endTime={Number(raffle.endTime)} />
              </div>
            ) : null}

            <div className="mt-6 grid grid-cols-2 gap-3 xl:grid-cols-4">
              <InfoTile icon={<Ticket size={13} />} label="Ticket price" value={usdcSmart(raffle.ticketPrice)} />
              <InfoTile icon={<Coins size={13} />} label="Tickets left" value={remaining.toLocaleString()} />
              <InfoTile icon={<Percent size={13} />} label="Platform fee" value={`${raffle.feeBps / 100}%`} />
              <InfoTile icon={<Timer size={13} />} label={view === 'active' ? 'Ends' : 'Ended'} value={<span className="text-sm">{formatDate(raffle.endTime)}</span>} />
            </div>
          </div>

          {view === 'drawn' ? <WinnerCard raffle={raffle} me={address} onReplay={() => setReplay(true)} /> : null}
          {view === 'cancelled' ? (
            <EmptyState
              icon={<Timer size={26} />}
              title="Raffle closed"
              body="This raffle ended without any ticket sales, so it was closed with nothing to pay out."
            />
          ) : null}

          <div className="card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="display flex items-center gap-2 text-xl font-semibold text-white">
                <Users size={18} className="text-gold-300" /> Players
              </h3>
              <span className="num text-sm text-white/50">{participants.length}</span>
            </div>
            {participants.length === 0 ? (
              <p className="py-6 text-center text-sm text-white/50">No tickets sold yet. The first buyer sets the pace.</p>
            ) : (
              <ul className="divide-y divide-white/[0.05]">
                {sortedParticipants.slice(0, 50).map((p) => {
                  const mine = !!address && p.address.toLowerCase() === address.toLowerCase()
                  const isWinner = view === 'drawn' && p.address.toLowerCase() === raffle.winner.toLowerCase()
                  return (
                    <li key={p.address} className="flex items-center justify-between gap-3 py-3">
                      <div className="flex min-w-0 items-center gap-2.5">
                        <span className="mono-addr truncate text-sm text-white/85">{shortAddr(p.address)}</span>
                        {mine ? <span className="rounded-full bg-gold-400/15 px-2 py-0.5 text-[11px] font-semibold text-gold-300">You</span> : null}
                        {isWinner ? <Trophy size={13} className="text-gold-300" /> : null}
                      </div>
                      <div className="num flex items-center gap-3 text-sm">
                        <span className="text-white/45">{raffle.ticketsSold > 0 ? ((p.tickets / raffle.ticketsSold) * 100).toFixed(1) : '0.0'}%</span>
                        <span className="min-w-[72px] text-right font-semibold text-white">
                          {p.tickets} {p.tickets === 1 ? 'ticket' : 'tickets'}
                        </span>
                      </div>
                    </li>
                  )
                })}
              </ul>
            )}
            {participants.length > 50 ? <p className="mt-3 text-center text-xs text-white/40">Showing the top 50 players.</p> : null}
          </div>
        </div>

        <div className="min-w-0 space-y-4 lg:sticky lg:top-32 lg:self-start">
          {showDraw ? (
            <DrawPanel raffle={raffle} view={view} participants={participantAddrs} onDone={refresh} onSession={setDrawSession} />
          ) : null}
          {view === 'active' ? <BuyPanel raffle={raffle} onBought={refresh} /> : null}
          {view === 'active' ? <Disclaimer compact /> : null}
          {view === 'drawn' ? <Disclaimer compact /> : null}
        </div>
      </div>

      <AnimatePresence>
        {replay && view === 'drawn' ? (
          <DrawStage
            key="replay"
            raffleId={raffle.id}
            mode="replay"
            participants={participantAddrs}
            me={address}
            result={{ winner: raffle.winner, winningTicket: raffle.winningTicket, ticketsSold: raffle.ticketsSold, payout: raffle.payout }}
            onClose={() => setReplay(false)}
          />
        ) : null}
      </AnimatePresence>
    </div>
  )
}
