import { useState } from 'react'
import { useAccount, useWriteContract } from 'wagmi'
import { toast } from 'sonner'
import { ArrowUpRight, Gift, Ticket, Trophy } from 'lucide-react'
import { RaffleCard, RaffleCardSkeleton } from '@/components/RaffleCard'
import { EmptyState, ErrorState, PageHeading, Spinner, StatusBadge, TxNotice } from '@/components/ui'
import { WalletGate } from '@/components/WalletButton'
import { useChainNow } from '@/hooks/useClock'
import { useContractTx } from '@/hooks/useContractTx'
import { useClaimable, useMyRaffles, type MyTicketRow } from '@/hooks/useRaffles'
import { deriveView, luckyDraw } from '@/lib/contract'
import { shortAddr, usdc, usdcSmart } from '@/lib/format'
import { Link } from '@/lib/router'

function ClaimCard() {
  const { address } = useAccount()
  const { amount, refetch } = useClaimable(address)
  const { writeContractAsync } = useWriteContract()
  const tx = useContractTx()
  if (amount === 0n && tx.phase === 'idle') return null

  const claim = async () => {
    const receipt = await tx.run(() => writeContractAsync({ ...luckyDraw, functionName: 'claim' }))
    if (receipt) {
      toast.success('Winnings claimed')
      await refetch()
    }
  }

  return (
    <div className="card mb-6 flex flex-wrap items-center justify-between gap-4 border-neon-400/30 p-5">
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-neon-400/10 text-neon-400">
          <Gift size={20} />
        </div>
        <div>
          <div className="label">Unclaimed winnings</div>
          <div className="display num text-2xl font-bold text-neon-400">{usdc(amount)} USDC</div>
          <p className="text-xs text-white/45">An automatic payout could not be delivered, so it is held for you here.</p>
        </div>
      </div>
      <div className="min-w-[200px] space-y-2">
        <button className="btn-gold w-full" onClick={() => void claim()} disabled={tx.busy || amount === 0n}>
          {tx.busy ? <Spinner /> : null}
          {tx.phase === 'wallet' ? 'Confirm in wallet' : tx.phase === 'confirming' ? 'Claiming' : 'Claim winnings'}
        </button>
        <TxNotice phase={tx.phase} hash={tx.hash} error={tx.error} successText="Winnings claimed." />
      </div>
    </div>
  )
}

function TicketRow({ row, me }: { row: MyTicketRow; me: string }) {
  const now = useChainNow()
  const { raffle, tickets } = row
  const view = deriveView(raffle, now)
  const won = view === 'drawn' && raffle.winner.toLowerCase() === me.toLowerCase()
  const outcome =
    view === 'drawn'
      ? won
        ? { text: `Won ${usdc(raffle.payout)} USDC`, tone: 'text-neon-400' }
        : { text: `Won by ${shortAddr(raffle.winner)}`, tone: 'text-white/45' }
      : view === 'ready'
        ? { text: 'Waiting for the draw', tone: 'text-gold-300' }
        : { text: 'In play', tone: 'text-white/55' }

  return (
    <Link
      to={`/raffle/${raffle.id.toString()}`}
      className={`card card-hover flex flex-wrap items-center justify-between gap-3 p-4 ${won ? '!border-neon-400/30' : ''}`}
    >
      <div className="flex items-center gap-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold-400/10 text-gold-300">
          {won ? <Trophy size={20} /> : <Ticket size={20} />}
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="display font-semibold text-white">Raffle #{raffle.id.toString()}</span>
            <StatusBadge view={view} />
          </div>
          <div className="num mt-0.5 text-sm text-white/55">
            {tickets} {tickets === 1 ? 'ticket' : 'tickets'} · {usdcSmart(raffle.ticketPrice * BigInt(tickets))} USDC spent
          </div>
        </div>
      </div>
      <div className={`flex items-center gap-2 text-sm font-medium ${outcome.tone}`}>
        {outcome.text} <ArrowUpRight size={15} className="text-white/30" />
      </div>
    </Link>
  )
}

export function MyRaffles() {
  const { address } = useAccount()
  const { created, tickets, isLoading, isError } = useMyRaffles(address)
  const [tab, setTab] = useState<'tickets' | 'created'>('tickets')

  const wins = tickets.filter((t) => t.raffle.status === 1 && address && t.raffle.winner.toLowerCase() === address.toLowerCase())
  const won = wins.reduce((sum, t) => sum + t.raffle.payout, 0n)

  return (
    <div>
      <PageHeading eyebrow="Your activity" title="My raffles" subtitle="Tickets you hold and raffles you started, all read live from the contract." />

      {!address ? (
        <div className="card mx-auto max-w-lg p-8">
          <WalletGate prompt="Connect your wallet to see your tickets and raffles.">
            <span />
          </WalletGate>
        </div>
      ) : (
        <>
          <ClaimCard />
          <div className="mb-6 grid gap-3 sm:grid-cols-3">
            <div className="card px-5 py-4">
              <div className="label">Raffles joined</div>
              <div className="display num text-2xl font-bold text-white">{tickets.length}</div>
            </div>
            <div className="card px-5 py-4">
              <div className="label">Wins</div>
              <div className="display num text-2xl font-bold text-white">{wins.length}</div>
            </div>
            <div className="card px-5 py-4">
              <div className="label">Total won</div>
              <div className="display num text-2xl font-bold text-neon-400">{usdc(won)} USDC</div>
            </div>
          </div>

          <div className="mb-5 flex gap-2" role="tablist">
            <button role="tab" aria-selected={tab === 'tickets'} data-active={tab === 'tickets'} className="chip" onClick={() => setTab('tickets')}>
              My tickets
            </button>
            <button role="tab" aria-selected={tab === 'created'} data-active={tab === 'created'} className="chip" onClick={() => setTab('created')}>
              Created by me
            </button>
          </div>

          {isError ? (
            <ErrorState message="Could not load your raffles." />
          ) : isLoading ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <RaffleCardSkeleton key={i} />
              ))}
            </div>
          ) : tab === 'tickets' ? (
            tickets.length === 0 ? (
              <EmptyState
                icon={<Ticket size={26} />}
                title="No tickets yet"
                body="Pick a live raffle and grab a few tickets. They will show up here."
                action={
                  <Link to="/" className="btn-gold">
                    Explore raffles
                  </Link>
                }
              />
            ) : (
              <div className="space-y-3">
                {tickets.map((row) => (
                  <TicketRow key={row.raffle.id.toString()} row={row} me={address} />
                ))}
              </div>
            )
          ) : created.length === 0 ? (
            <EmptyState
              icon={<Gift size={26} />}
              title="You have not created a raffle"
              body="Launch your own in under a minute. You choose the price, the size and the deadline."
              action={
                <Link to="/create" className="btn-gold">
                  Create a raffle
                </Link>
              }
            />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {created.map((r, i) => (
                <RaffleCard key={r.id.toString()} raffle={r} index={i} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}
