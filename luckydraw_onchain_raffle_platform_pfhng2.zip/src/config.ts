/**
 * wagmi configuration
 * Built with Arc Studio — https://studio.arc.io
 */

import { http, createConfig } from 'wagmi'
import { mainnet } from 'wagmi/chains'
import { arc } from 'viem/chains'
import { requireChain } from './onchain-facts'
import { injected } from 'wagmi/connectors'
import { registerChain } from './tracing'

// Pre-register chain RPC URLs so trace events show correct chain names immediately
const ARC_RPC = requireChain(arc.id).rpcUrls[0]
registerChain(arc.id, ARC_RPC)

export const config = createConfig({
  chains: [arc, mainnet], // Arc Mainnet first (default); Ethereum mainnet is for ENS resolution
  connectors: [injected()],
  transports: {
    [arc.id]: http(ARC_RPC),
    [mainnet.id]: http(), // ENS resolution uses mainnet
  },
})
