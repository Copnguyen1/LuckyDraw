# LuckyDraw

> Built with Arc Studio - money-powered apps in minutes

Project memory for future agents and humans.

## What This App Does

Onchain USDC raffle platform on Arc Testnet. Users create raffles (ticket price, max tickets, duration), buy tickets with USDC, anyone triggers the draw when ready, and the contract picks a winner from `blockhash` and pays the pot minus a 3% fee. Demo-only randomness, disclaimed in the UI, README and contract NatSpec.

## Tech Stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS v3, framer-motion
- Web3: wagmi v2, viem v2, ConnectKit (injected wallets)
- Contracts: Solidity 0.8.28 + Foundry. Sources in `contracts/`, tests in `contracts/test/*.t.sol` (98 tests). `bun run contracts:build`, `bun run contracts:test`.
- Chain: Arc Mainnet (5042). USDC (6 decimals) at 0x3600000000000000000000000000000000000000

## Deployments

- LuckyDraw (Arc Mainnet, chain 5042): `0x5CD290b15206cf9743CF91614Ef714D8b5C53721`, supplied by the user and read by the app from `VITE_LUCKYDRAW_ADDRESS` in `.env`. Source not verified on an explorer; checked by reading treasury/owner/feeBps and confirming all 49 ABI function selectors and event topics are present in its bytecode (bytecode is larger than our local build, so compiler settings differ). Owner and treasury: 0x1a31132831578f9249318ab31c0fcbd093f5de17. Earlier addresses: 0x7057230F08e3CD5CEb2eF7d2FbB4EFC295C9B291 (mainnet, no code), 0xee920aed93aebfb7f2ebbe015462baa15d8da3cf (testnet), 0x707f51048dfd85381c71e1ef22771e2706a85dcf (retired testnet).

## Key Files

- `src/App.tsx` - shell, hash routes, clock provider
- `src/pages/` - Explore, Create, RaffleDetail, MyRaffles, Winners, Fair
- `src/components/` - RaffleCard, BuyPanel, DrawPanel, DrawStage (reveal animation), Confetti, Header, Logo, ui primitives
- `src/hooks/` - contract reads (`useRaffles`), wallet and USDC (`useWallet`), tx state (`useContractTx`), chain clock (`useClock`)
- `src/lib/abi.ts` - generated from `contracts/out/LuckyDraw.sol/LuckyDraw.json`; regenerate if the contract changes
- `src/lib/contract.ts` - address, limits, raffle view derivation

## Decisions

- Single-transaction draw (as requested). Known limitation: a ticket holder can simulate the draw and only submit when winning. A commit-then-reveal draw (two transactions) or VRF would fix it.
- Deferred payout: failed winner transfers are credited to `claimable` and claimed from "My raffles".
- Hash-based routing (`#/raffle/1`) so no server config is needed.

## To Run

```bash
bun install
bun run dev
```
