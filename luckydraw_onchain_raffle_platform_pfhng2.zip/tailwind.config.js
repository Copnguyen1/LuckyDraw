/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#06060b',
          900: '#0a0a12',
          800: '#10101a',
          700: '#171723',
          600: '#20202f',
        },
        gold: {
          200: '#FFEDB3',
          300: '#FFE08A',
          400: '#F8C84A',
          500: '#E9AD2B',
          600: '#C98A12',
        },
        neon: {
          400: '#38FFB3',
          500: '#1FE39A',
        },
        rose: {
          450: '#FF6B8B',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'ui-sans-serif', 'sans-serif'],
        sans: ['"DM Sans"', 'ui-sans-serif', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        gold: '0 0 0 1px rgba(248,200,74,0.35), 0 10px 40px -10px rgba(248,200,74,0.45)',
        neon: '0 0 24px -4px rgba(56,255,179,0.55)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'spin-slow': {
          to: { transform: 'rotate(360deg)' },
        },
        'pulse-ring': {
          '0%': { boxShadow: '0 0 0 0 rgba(248,200,74,0.45)' },
          '100%': { boxShadow: '0 0 0 14px rgba(248,200,74,0)' },
        },
        float: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.35s cubic-bezier(0.25,0.1,0.25,1) both',
        shimmer: 'shimmer 2.2s linear infinite',
        'spin-slow': 'spin-slow 6s linear infinite',
        'spin-fast': 'spin-slow 1.1s linear infinite',
        'pulse-ring': 'pulse-ring 1.8s ease-out infinite',
        float: 'float 4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
